import java.util.ArrayList;

public final class aj extends ak {
   public aj(ab var1) {
      super(var1);
   }

   public final Object a(bH var1) {
      bL var2;
      bL var4 = var2 = (bL)var1.a(bR.b);
      av var3 = new av(var4);
      if (var1.a().size() > 0) {
         ArrayList var17 = ((bH)var1.a().get(0)).a();
         ArrayList var5 = (ArrayList)var2.a(bZ.e);
         av var7 = var3;
         ArrayList var6 = var5;
         var5 = var17;
         ao var8 = new ao(this);
         ai var18 = new ai(this);

         for(int var9 = 0; var9 < var6.size(); ++var9) {
            bL var10;
            bE var11 = (var10 = (bL)var6.get(var9)).a();
            Z var12 = var7.a(var10.a());
            bH var13 = (bH)var5.get(var9);
            bP var20;
            if (var12.a() instanceof Z[] && !var13.a().a()) {
               var20 = var13.a().a();
               var10.a(var20);
               Z var22 = var8.a(var13);
               var12.a(var22.a());
               break;
            }

            if (var11 == bU.f) {
               var20 = var10.a();
               bP var14 = var13.a().a();
               Object var15 = var8.a(var13);
               var18.a(var13, var10, var12, var20, var15, var14);
            } else {
               Z var21;
               if ((var21 = var8.a(var13)).a() instanceof Z[]) {
                  var12.a(var21.a());
               } else {
                  var12.a(var21);
               }
            }
         }
      }

      super.a.a(var3);
      this.a(var1, var2.a());
      bH var19 = ((bF)var2.a(bZ.d)).a();
      Object var16 = (new at(this)).a(var19);
      super.a.a();
      this.b(var1, var2.a());
      return var16;
   }
}
