import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

public final class cl {
   private static final Set a;
   private static final List b;
   public static final List a;
   public static final Pattern a;
   public static final Pattern b;
   public static final Pattern c;
   public static final Pattern d;
   public static final Pattern e;
   public static final Pattern f;

   static {
      a = aL.a.keySet();
      b = cm.a(aL.b.keySet(), aL.a, aL.c);
      a = cm.a(a, b, aL.b);
      a = Pattern.compile("(//.*)|(/\\*(?:.|[\\n\\r])*?\\*/)", 2);
      b = Pattern.compile("((')(.*?)('))|((\")(.*?)(\"))", 2);
      c = Pattern.compile("(\\b)((\\d*[.]?\\d+([Ee][+-]?[\\d]+)?)|([Ee][+-]?[\\d]+))(\\b)", 2);
      d = Pattern.compile("[+\\-'*!=<>/:)(\\]\\[;@^,.&%|]", 2);
      e = Pattern.compile("(\\b)(" + String.join("|", a) + ")(\\b)", 2);
      f = Pattern.compile("(\\b)(" + String.join("|", b) + ")(\\b)", 2);
      Collections.sort(a);
   }
}
