import java.util.ArrayList;

public final class cg {
   public cf a;
   public final ArrayList a = new ArrayList();
}
