public final class bA extends aK {
   public bA(aE var1) {
      super(var1);
   }

   public final void a() {
      StringBuilder var1 = new StringBuilder();
      String var5 = null;
      String var6 = null;
      char var7 = '+';
      boolean var8 = false;
      super.a = aL.aw;
      String var4 = this.a(var1);
      if (super.a != aL.az) {
         label81: {
            char var9;
            if ((var9 = this.a()) == '.') {
               if (this.c() == '.') {
                  var8 = true;
               } else {
                  super.a = aL.ax;
                  var1.append(var9);
                  this.b();
                  var5 = this.a(var1);
                  if (super.a == aL.az) {
                     break label81;
                  }
               }
            }

            var9 = this.a();
            if (!var8 && (var9 == 'E' || var9 == 'e')) {
               super.a = aL.ax;
               var1.append(var9);
               if ((var9 = this.b()) == '+' || var9 == '-') {
                  var1.append(var9);
                  var7 = var9;
                  this.b();
               }

               var6 = this.a(var1);
            }

            int var3;
            if (super.a == aL.aw) {
               var3 = this.a(var4);
               if (super.a != aL.az) {
                  super.a = var3;
               }
            } else if (super.a == aL.ax) {
               double var10 = 0.0D;
               int var13 = this.a(var6);
               String var14 = var4;
               if (var7 == '-') {
                  var13 = -var13;
               }

               if (var5 != null) {
                  var13 -= var5.length();
                  var14 = var4 + var5;
               }

               float var15;
               if (Math.abs(var13 + var4.length()) > 37) {
                  super.a = aL.az;
                  super.a = aM.H;
                  var15 = 0.0F;
               } else {
                  for(var3 = 0; var3 < var14.length(); var10 = var10 * 10.0D + (double)Character.getNumericValue(var14.charAt(var3++))) {
                  }

                  if (var13 != 0) {
                     var10 *= Math.pow(10.0D, (double)var13);
                  }

                  var15 = (float)var10;
               }

               float var12 = var15;
               if (super.a != aL.az) {
                  super.a = var12;
               }
            }
         }
      }

      super.a = var1.toString();
   }

   private String a(StringBuilder var1) {
      char var2;
      if (!Character.isDigit(var2 = this.a())) {
         super.a = aL.az;
         super.a = aM.j;
         return null;
      } else {
         StringBuilder var3;
         for(var3 = new StringBuilder(); Character.isDigit(var2); var2 = this.b()) {
            var1.append(var2);
            var3.append(var2);
         }

         return var3.toString();
      }
   }

   private int a(String var1) {
      if (var1 == null) {
         return 0;
      } else {
         int var2 = 0;
         int var3 = -1;

         for(int var4 = 0; var4 < var1.length() && var2 >= var3; var2 = var2 * 10 + Character.getNumericValue(var1.charAt(var4++))) {
            var3 = var2;
         }

         if (var2 >= var3) {
            return var2;
         } else {
            super.a = aL.az;
            super.a = aM.G;
            return 0;
         }
      }
   }
}
