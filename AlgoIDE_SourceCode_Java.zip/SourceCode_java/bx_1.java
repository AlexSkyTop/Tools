import java.util.EnumSet;

public final class bx extends bq {
   private boolean a = false;
   private static final EnumSet a;
   private static final EnumSet d;

   public bx(bq var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      String var2 = var1.a;
      if (!super.a.a.get()) {
         var2 = var2.toLowerCase();
      }

      bL var3;
      if ((var3 = super.a.c(var2)) == null) {
         aH var10000 = super.a;
         aH.a(var1, aM.c);
      }

      return this.a(var1, var3);
   }

   public final bH b(aF var1) {
      this.a = true;
      return this.a(var1);
   }

   public final bH a(aF var1, bL var2) {
      bE var3;
      if ((var3 = var2.a()) != bU.d && var3 != bU.f && var3 != bU.g && (!this.a || var3 != bU.k)) {
         aH var10000 = super.a;
         aH.a(var1, aM.h);
      }

      var2.a(var1.a);
      bH var6;
      (var6 = bG.a(bT.E)).a(bR.b, var2);
      var1 = super.a.a();
      bP var5 = var2.a();
      if (!this.a) {
         while(a.contains((aL)var1.a)) {
            bH var4 = var1.a == aL.al ? this.a(var5) : this.b(var5);
            var1 = super.a.a;
            var5 = var4.a();
            var6.a(var4);
         }
      }

      var6.a(var5);
      return var6;
   }

   private bH a(bP var1) {
      bg var3 = new bg(this);
      bH var4 = bG.a(bT.F);

      aH var10000;
      aF var2;
      do {
         var2 = super.a.a();
         if (var1.a() == cc.d) {
            bH var5;
            bP var6 = (var5 = var3.a(var2)).a();
            if (!cb.j((bP)var1.a(cd.e), var6)) {
               var10000 = super.a;
               aH.a(var2, aM.d);
            }

            var4.a(var5);
            var1 = (bP)var1.a(cd.f);
         } else {
            var10000 = super.a;
            aH.a(var2, aM.I);
            var3.a(var2);
         }
      } while(super.a.a.a == aL.T);

      if ((var2 = this.a(d)).a == aL.am) {
         super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var2, aM.A);
      }

      var4.a(var1);
      return var4;
   }

   private bH b(bP var1) {
      bH var2 = bG.a(bT.G);
      aF var3;
      aG var4 = (var3 = super.a.a()).a;
      bO var5 = var1.a();
      aH var10000;
      if (var4 == aL.av && var5 == cc.e) {
         bK var7 = (bK)var1.a(cd.h);
         String var6 = var3.a;
         if (!super.a.a.get()) {
            var6 = var6.toLowerCase();
         }

         bL var8;
         if ((var8 = var7.b(var6)) != null) {
            var1 = var8.a();
            var8.a(var3.a);
            var2.a(bR.b, var8);
         } else {
            var10000 = super.a;
            aH.a(var3, aM.g);
         }
      } else {
         var10000 = super.a;
         aH.a(var3, aM.g);
      }

      super.a.a();
      var2.a(var1);
      return var2;
   }

   static {
      a = EnumSet.of(aL.al, aL.S);
      d = EnumSet.of(aL.am, aL.Z, aL.U);
   }
}
