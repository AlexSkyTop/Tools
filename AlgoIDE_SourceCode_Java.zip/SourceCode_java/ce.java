import java.util.HashMap;

public final class ce extends HashMap implements bP {
   private final cc a;
   private bL a;

   public ce(cc var1) {
      this.a = var1;
      this.a = null;
   }

   public ce(String var1) {
      this.a = cc.d;
      ce var2;
      (var2 = new ce(cc.c)).a(cd.b, bV.b);
      var2.a(cd.c, 1);
      var2.a(cd.d, var1.length());
      this.put(cd.e, var2);
      this.put(cd.f, bV.e);
      this.put(cd.g, var1.length());
   }

   public final bO a() {
      return this.a;
   }

   public final void a(bL var1) {
      this.a = var1;
   }

   public final bL a() {
      return this.a;
   }

   public final void a(cd var1, Object var2) {
      this.put(var1, var2);
   }

   public final Object a(cd var1) {
      return this.get(var1);
   }

   public final boolean a() {
      if (this.a == cc.d) {
         bP var1 = (bP)this.get(cd.f);
         bP var2 = (bP)this.get(cd.e);
         return var1.a() == bV.e && var2.a() == bV.b;
      } else {
         return false;
      }
   }

   public final bP a() {
      return (bP)(this.a == cc.c ? (bP)this.get(cd.b) : this);
   }
}
