public interface z {
   void onUpdate();
}
