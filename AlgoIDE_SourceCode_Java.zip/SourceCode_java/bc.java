import java.util.EnumSet;
import java.util.HashSet;

public class bc extends aI {
   static final EnumSet b;
   static final EnumSet c;
   static final EnumSet d;
   static final EnumSet e;
   private static HashSet a;

   public bc(aI var1) {
      super(var1);
   }

   public bL a(aF var1, bL var2) {
      for(aG var3 = (var1 = super.a.a).a; a.contains(var3); var3 = (var1 = super.a.a).a) {
         if (var3 == aL.G) {
            var1 = super.a.a();
            bw var4;
            (var4 = new bw(this)).a = bU.d;
            var4.a(var1, (bL)null);
         } else if (var3 == aL.e) {
            var1 = super.a.a();
            (new ba(this)).a(var1, (bL)null);
         } else if (var3 == aL.C) {
            var1 = super.a.a();
            (new bt(this)).a(var1, (bL)null);
         } else {
            (new bd(this)).a(var1, var2);
            if ((var1 = super.a.a).a == aL.U) {
               while(var1.a == aL.U) {
                  var1 = super.a.a();
               }
            }
         }
      }

      return null;
   }

   static {
      e = (d = (c = (b = EnumSet.of(aL.e, aL.C, aL.G, aL.q, aL.k, aL.c)).clone()).clone()).clone();
      (a = new HashSet()).add(aL.G);
      a.add(aL.e);
      a.add(aL.C);
      a.add(aL.q);
      a.add(aL.k);
   }
}
