import java.util.EnumSet;

final class bl extends bu {
   private static final EnumSet a;

   protected bl(bu var1) {
      super(var1);
   }

   public final bP a(aF var1) {
      bP var2 = bN.a(cc.e);
      var1 = super.a.a();
      var2.a(cd.h, super.a.a());
      bw var3;
      (var3 = new bw(this)).a = bU.e;
      var3.a(var1, (bL)null);
      super.a.b();
      if ((var1 = this.a(a)).a == aL.i) {
         super.a.a();
      } else {
         aH var10000 = super.a;
         aH.a(var1, aM.u);
      }

      return var2;
   }

   static {
      (a = bc.d.clone()).add(aL.i);
      a.add(aL.U);
   }
}
