final class J implements Runnable {
   private String a;
   private int a;
   // $FF: synthetic field
   private F a;

   J(F var1, String var2, int var3) {
      this.a = var1;
      super();
      this.a = var2;
      this.a = var3;
   }

   public final void run() {
      F.a(this.a).a(this.a, this.a);
      F.a(this.a).setCaretPosition(this.a + this.a.length());
      F.a(this.a).moveCaretPosition(this.a);
   }
}
