// $FF: synthetic class
final class bh {
   // $FF: synthetic field
   static final int[] a;
   // $FF: synthetic field
   static final int[] b = new int[bU.values().length];

   static {
      try {
         b[bU.a.ordinal()] = 1;
      } catch (NoSuchFieldError var17) {
      }

      try {
         b[bU.b.ordinal()] = 2;
      } catch (NoSuchFieldError var16) {
      }

      try {
         b[bU.k.ordinal()] = 3;
      } catch (NoSuchFieldError var15) {
      }

      a = new int[aL.values().length];

      try {
         a[aL.K.ordinal()] = 1;
      } catch (NoSuchFieldError var14) {
      }

      try {
         a[aL.W.ordinal()] = 2;
      } catch (NoSuchFieldError var13) {
      }

      try {
         a[aL.L.ordinal()] = 3;
      } catch (NoSuchFieldError var12) {
      }

      try {
         a[aL.M.ordinal()] = 4;
      } catch (NoSuchFieldError var11) {
      }

      try {
         a[aL.N.ordinal()] = 5;
      } catch (NoSuchFieldError var10) {
      }

      try {
         a[aL.f.ordinal()] = 6;
      } catch (NoSuchFieldError var9) {
      }

      try {
         a[aL.m.ordinal()] = 7;
      } catch (NoSuchFieldError var8) {
      }

      try {
         a[aL.av.ordinal()] = 8;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a[aL.aw.ordinal()] = 9;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a[aL.ax.ordinal()] = 10;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a[aL.ay.ordinal()] = 11;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a[aL.ak.ordinal()] = 12;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a[aL.n.ordinal()] = 13;
      } catch (NoSuchFieldError var2) {
      }

      try {
         a[aL.ai.ordinal()] = 14;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[aL.al.ordinal()] = 15;
      } catch (NoSuchFieldError var0) {
      }
   }
}
