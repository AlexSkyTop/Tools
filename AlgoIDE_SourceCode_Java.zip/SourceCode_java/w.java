import java.io.InputStream;

final class w extends InputStream {
   private final Object a = new Object();
   private final A a;

   public w(A var1) {
      this.a = var1;
   }

   public final int read() {
      synchronized(this.a) {
         return this.a.a();
      }
   }
}
