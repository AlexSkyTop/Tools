import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.SwingUtilities;
import javax.swing.text.AbstractDocument;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.DefaultHighlighter.DefaultHighlightPainter;

public final class a {
   private final V a;
   final t a;
   private final N a;
   private ab a;

   public a(t var1, N var2, V var3) {
      this.a = var1;
      this.a = var2;
      this.a = var3;
   }

   public final List a(String var1) {
      ArrayList var2 = new ArrayList();
      if (var1 != null && !var1.isEmpty()) {
         ca var3 = new ca();

         bF var10000;
         String var4;
         bL var6;
         Iterator var7;
         try {
            aN.a(var1, var3, this.a).a();
            var10000 = (bF)(var6 = var3.a()).a(bZ.d);
            var7 = ((bK)var6.a(bZ.c)).a().iterator();

            while(var7.hasNext()) {
               var4 = ((bL)var7.next()).a();
               var2.add(var4);
            }
         } catch (Exception var5) {
            var10000 = (bF)(var6 = var3.a()).a(bZ.d);
            var7 = ((bK)var6.a(bZ.c)).a().iterator();

            while(var7.hasNext()) {
               var4 = ((bL)var7.next()).a();
               var2.add(var4);
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   public final void a(String var1) {
      if (var1 != null && !var1.isEmpty()) {
         t var4;
         (var4 = this.a).a = 0;
         ((AbstractDocument)var4.getDocument()).setDocumentFilter((DocumentFilter)null);
         var4.setText("");
         ((AbstractDocument)var4.getDocument()).setDocumentFilter(new y(var4));
         this.a.c.set(false);
         w var2 = this.a.a;
         PrintStream var3 = this.a.a;
         PrintStream var5 = this.a.b;
         (new Thread(() -> {
            try {
               ca var5x = new ca();
               aN.a(var1, var5x, this.a).a();
               bF var10000 = (bF)var5x.a().a(bZ.d);
               V var6 = this.a;
               this.a = new ab(var5x, new aA(), new aJ(new aE(new BufferedReader(new InputStreamReader(var2)))), var3, var6);
               ab var22 = this.a;
               c var21 = new c(this);
               var22.a.a.add(0, var21);
               this.a.a();
               return;
            } catch (InterruptedException var14) {
               return;
            } catch (StackOverflowError var15) {
               var5.println("Erreur de débordement de pile");
               return;
            } catch (cj var16) {
               var5.println(var16.a);
               SwingUtilities.invokeLater(() -> {
                  aF var2 = var16.a;
                  N var6 = this.a;

                  try {
                     int var3 = var2.a;
                     int var4 = var2.b;
                     int var7 = (var3 = var6.a(var3 - 1) + var4) + var2.a.length();
                     DefaultHighlightPainter var8 = new DefaultHighlightPainter(var6.a);
                     var6.getHighlighter().addHighlight(var3, var7, var8);
                     var6.getDocument().addDocumentListener(var6);
                  } catch (BadLocationException var5) {
                     throw new RuntimeException(var5);
                  }
               });
               return;
            } catch (ck var17) {
               var5.println(var17.a);
               return;
            } catch (ArrayIndexOutOfBoundsException var18) {
               var5.println("Indice de tableau hors limites");
            } catch (Error | Exception var19) {
               var5.println("Erreur inconnue");
               return;
            } finally {
               var3.println("\n\n--------------\n[Fin de programme]");
               if (this.a != null) {
                  this.a.b();
               }

            }

         })).start();
      }
   }
}
