public final class bm extends bq {
   public bm(bq var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      var1 = super.a.a();
      bH var2 = bG.a(bT.c);
      bH var3 = bG.a(bT.d);
      (new bq(this)).a(var1, var2, aL.F);
      aH var10000;
      if ((var1 = super.a.a).a == aL.F) {
         var1 = super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var1, aM.D);
      }

      bH var4 = (new bg(this)).a(var1);
      var3.a(var4);
      var2.a(var3);
      if (!cb.c(var4.a())) {
         var10000 = super.a;
         aH.a(var1, aM.d);
      }

      return var2;
   }
}
