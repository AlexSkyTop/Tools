import java.util.ArrayList;
import java.util.EnumSet;

final class aO extends bu {
   private static final EnumSet a;
   private static final EnumSet c;
   private static final EnumSet d;
   private static final EnumSet e;
   private static final EnumSet f;
   private static final EnumSet g;

   protected aO(bu var1) {
      super(var1);
   }

   public final bP a(aF var1) {
      bP var2 = bN.a(cc.d);
      super.a.a();
      aH var10000;
      if ((var1 = this.a(a)).a != aL.al) {
         var10000 = super.a;
         aH.a(var1, aM.y);
      }

      aO var11 = this;
      bP var4 = var2;
      super.a.a();

      boolean var3;
      do {
         var3 = false;
         aF var5 = var11.a(e);
         bP var8 = (new bo(var11)).a(var5);
         var4.a(cd.e, var8);
         if (var8 != null) {
            bO var9 = var8.a();
            int var10 = 0;
            if (var9 == cc.c) {
               Integer var13 = (Integer)var8.a(cd.c);
               Integer var6 = (Integer)var8.a(cd.d);
               if (var13 != null && var6 != null) {
                  var10 = var6 - var13 + 1;
               }
            } else if (var9 == cc.b) {
               var10 = ((ArrayList)var8.a(cd.a)).size();
            } else {
               var10000 = var11.a;
               aH.a(var5, aM.i);
            }

            var4.a(cd.g, var10);
         }

         aG var14;
         if ((var14 = (var5 = var11.a(g)).a) != aL.T && var14 != aL.am) {
            if (e.contains((aL)var14)) {
               var10000 = var11.a;
               aH.a(var5, aM.r);
               var3 = true;
            }
         } else if (var14 == aL.T) {
            bP var12 = bN.a(cc.d);
            var4.a(cd.f, var12);
            var4 = var12;
            var11.a.a();
            var3 = true;
         }
      } while(var3);

      if ((var1 = this.a(c)).a == aL.am) {
         super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var1, aM.A);
      }

      if ((var1 = this.a(d)).a == aL.o) {
         var1 = super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var1, aM.z);
      }

      var4.a(cd.f, (new bu(this)).a(var1));
      return var2;
   }

   static {
      (a = bo.a.clone()).add(aL.al);
      a.add(aL.am);
      a.add(aL.o);
      c = EnumSet.of(aL.am, aL.o, aL.U);
      (d = bu.b.clone()).add(aL.o);
      d.add(aL.U);
      (e = bo.a.clone()).add(aL.T);
      f = EnumSet.of(aL.am, aL.o, aL.U);
      (g = e.clone()).addAll(f);
   }
}
