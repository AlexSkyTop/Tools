public final class aw implements Z {
   private Object a = null;

   public aw(Object var1) {
      this.a = var1;
   }

   public final void a(Object var1) {
      this.a = var1;
   }

   public final Object a() {
      return this.a;
   }
}
