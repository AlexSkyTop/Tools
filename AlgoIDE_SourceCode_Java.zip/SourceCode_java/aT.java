import java.util.ArrayList;
import java.util.EnumSet;

public class aT extends bq {
   private static final EnumSet a;

   public aT(bq var1) {
      super(var1);
   }

   public bH a(aF var1) {
      String var2 = var1.a;
      if (!super.a.a.get() || aL.a.contains(var2.toLowerCase())) {
         var2 = var2.toLowerCase();
      }

      return ((bq)((bJ)super.a.c(var2).a(bZ.b) == bW.a ? new aS(this) : new aU(this))).a(var1);
   }

   protected final bH a(aF var1, bL var2, boolean var3, boolean var4, boolean var5) {
      bg var6 = new bg(this);
      bH var7 = bG.a(bT.f);
      ArrayList var8 = null;
      int var9 = 0;
      int var10 = -1;
      if (var3) {
         var9 = (var8 = (ArrayList)var2.a(bZ.e)) != null ? var8.size() : 0;
      }

      aH var10000;
      if (var1.a != aL.ai) {
         if (var9 != 0) {
            var10000 = super.a;
            aH.a(var1, aM.L);
         }

         return null;
      } else {
         label106:
         while(true) {
            var1 = super.a.a();

            while(var1.a != aL.aj) {
               bH var16 = var6.a(var1);
               bP var12;
               if (var3) {
                  ++var10;
                  if (var10 < var9 && var8 != null) {
                     bL var18 = (bL)var8.get(var10);
                     bE var14 = var18.a();
                     var12 = var18.a();
                     bP var15 = var16.a();
                     if (var14 == bU.g) {
                        if (var16.a() != bT.E || !cb.j(var15, var12)) {
                           var10000 = super.a;
                           aH.a(var1, aM.m);
                        }
                     } else if (!cb.j(var12, var15)) {
                        var10000 = super.a;
                        aH.a(var1, aM.d);
                     }
                  } else if (var10 == var9) {
                     var10000 = super.a;
                     aH.a(var1, aM.L);
                  }
               } else if (var4) {
                  bP var17;
                  bO var20 = (var17 = var16.a()).a();
                  if (var16.a() != bT.E || var20 != cc.a && var17 != bV.d && !var17.a() && (var20 != cc.c || var17.a() != bV.b)) {
                     var10000 = super.a;
                     aH.a(var1, aM.m);
                  }
               } else if (var5) {
                  bH var11 = var16;
                  (var16 = bG.a(bT.L)).a(var11);
                  if ((var12 = var11.a().a()).a() != cc.a && var12 != bV.d && !var12.a()) {
                     var10000 = super.a;
                     aH.a(var1, aM.d);
                  }

                  var1 = super.a.a;
                  var16.a(this.b(var1));
                  var1 = super.a.a;
                  var16.a(this.b(var1));
               }

               var7.a(var16);
               aG var19;
               if ((var19 = (var1 = this.a(a)).a) == aL.T) {
                  continue label106;
               }

               if (bg.a.contains((aL)var19)) {
                  var10000 = super.a;
                  aH.a(var1, aM.r);
               } else if (var19 != aL.aj) {
                  var1 = this.a(bg.a);
               }
            }

            var1 = super.a.a();
            if (var7.a().size() == 0) {
               return null;
            }

            if (var3 && var10 != var9 - 1) {
               var10000 = super.a;
               aH.a(var1, aM.L);
            }

            return var7;
         }
      }
   }

   private bH b(aF var1) {
      if (var1.a == aL.V) {
         var1 = super.a.a();
         bH var2;
         if ((var2 = (new bg(this)).a(var1)).a() == bT.H) {
            return var2;
         } else {
            aH var10000 = super.a;
            aH.a(var1, aM.j);
            return null;
         }
      } else {
         return null;
      }
   }

   static {
      (a = bg.a.clone()).add(aL.T);
      a.add(aL.aj);
   }
}
