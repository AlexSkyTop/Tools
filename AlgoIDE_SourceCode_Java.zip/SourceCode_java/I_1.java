import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.KeyStroke;

final class I extends AbstractAction {
   // $FF: synthetic field
   private F a;

   private I(F var1) {
      this.a = var1;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      int var2 = F.a(this.a).getSelectionEnd();
      F.a(this.a).a(" ", var2);
      F.a(this.a).setCaretPosition(var2 + 1);
      F.a(this.a).getInputMap().remove(KeyStroke.getKeyStroke("ENTER"));
      F.a(this.a).getActionMap().remove("commit");
   }

   // $FF: synthetic method
   I(F var1, byte var2) {
      this(var1);
   }
}
