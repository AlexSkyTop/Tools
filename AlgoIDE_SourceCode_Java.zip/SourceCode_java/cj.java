public final class cj extends Exception {
   public final aF a;
   private final String b;
   private final String c;
   public final String a;

   public cj(String var1, String var2, aF var3) {
      this.b = var1;
      this.c = var2;
      this.a = var3;
      this.a = var1 + "\n" + var2;
   }
}
