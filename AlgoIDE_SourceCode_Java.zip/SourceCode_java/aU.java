public final class aU extends aT {
   public aU(aT var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      // $FF: Couldn't be decompiled
   }

   private boolean a(aF var1, bH var2, int var3) {
      if ((var2 != null || var3 != 0) && (var2 == null || var2.a().size() != var3)) {
         aH var10000 = super.a;
         aH.a(var1, aM.L);
         return false;
      } else {
         return true;
      }
   }
}
