import javax.swing.SwingUtilities;

public final class c implements ch {
   // $FF: synthetic field
   private a a;

   public c(a var1) {
      this.a = var1;
      super();
   }

   public final void a(cf var1) {
      int var2 = var1.a;
      t var10000;
      switch(b.a[var2 - 1]) {
      case 1:
         var10000 = this.a.a;
         SwingUtilities.invokeLater(var10000::a);
         return;
      case 2:
         var10000 = this.a.a;
         SwingUtilities.invokeLater(var10000::b);
      default:
      }
   }
}
