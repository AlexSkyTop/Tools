import java.awt.Font;
import java.io.PrintStream;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.text.AbstractDocument;

public final class t extends JTextArea {
   private int b = 0;
   public PrintStream a;
   public w a;
   public PrintStream b;
   private final A a = new A();
   private s a;
   private s b;
   private byte[] a;
   public int a = 0;

   public t(int var1) {
      super(5, 30);
      this.a(var1);
      ((AbstractDocument)this.getDocument()).setDocumentFilter(new y(this));
      this.getInputMap(0);
      ActionMap var3;
      Action var2 = (var3 = this.getActionMap()).get("insert-break");
      var3.put("insert-break", new u(this, var2));
      this.a = new byte[2048];
      this.a = new s();
      this.b = new s();
      this.a = new w(this.a);
      this.a = new PrintStream(new x(this.a, () -> {
         SwingUtilities.invokeLater(this::c);
      }, (byte)0));
      this.b = new PrintStream(new v(this.b, () -> {
         SwingUtilities.invokeLater(this::d);
      }));
   }

   private void c() {
      int var1 = Math.min(this.a.a(), this.a.length);

      try {
         var1 = this.a.a(this.a, 0, var1);
         String var3 = new String(this.a, 0, var1);
         this.b += var3.length();
         SwingUtilities.invokeLater(() -> {
            this.append(var3);
            this.setCaretPosition(this.getText().length());
            this.a = this.getCaretPosition();
         });
      } catch (InterruptedException var2) {
      }
   }

   private void d() {
      int var1 = Math.min(this.b.a(), this.a.length);

      try {
         var1 = this.b.a(this.a, 0, var1);
         String var3 = new String(this.a, 0, var1);
         this.b += var3.length();
         SwingUtilities.invokeLater(() -> {
            this.append(var3);
         });
      } catch (InterruptedException var2) {
      }
   }

   public final void a() {
      this.requestFocus();
   }

   public final void b() {
   }

   public final void a(int var1) {
      this.setFont(new Font("Monospaced", 0, var1));
   }

   public final void b(int var1) {
      this.setFont(new Font("Monospaced", 0, Math.max(Math.min(this.getFont().getSize() + var1, 60), 6)));
   }

   // $FF: synthetic method
   static int a(t var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static int a(t var0, int var1) {
      return var0.a = var1;
   }

   // $FF: synthetic method
   static A a(t var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static int b(t var0, int var1) {
      return var0.b = var1;
   }
}
