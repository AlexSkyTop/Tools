public final class aR extends aI {
   public aR(bd var1) {
      super(var1);
   }

   public final bH a(aF var1, bL var2) {
      bc var3 = new bc(this);
      bq var4 = new bq(this);
      var3.a(var1, var2);
      aG var5 = (var1 = this.a(bq.b)).a;
      bH var6 = null;
      if (var5 == aL.c) {
         var6 = var4.a(var1);
      } else {
         aH var10000 = super.a;
         aH.a(var1, aM.o);
      }

      return var6;
   }
}
