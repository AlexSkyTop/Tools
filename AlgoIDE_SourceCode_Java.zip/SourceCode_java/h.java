import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

final class h extends AbstractAction {
   // $FF: synthetic field
   private d a;

   h(d var1) {
      this.a = var1;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      (new C(this.a, "Settings")).pack();
   }
}
