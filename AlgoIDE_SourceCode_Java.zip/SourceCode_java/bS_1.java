import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public final class bS extends HashMap implements bH {
   private final bI a;
   private bS a;
   private final ArrayList a;
   private bP a;

   public bS(bI var1) {
      this.a = var1;
      this.a = null;
      this.a = new ArrayList();
   }

   public final bI a() {
      return this.a;
   }

   public final bH a() {
      return this.a;
   }

   public final void a(bP var1) {
      this.a = var1;
   }

   public final bP a() {
      return this.a;
   }

   public final bH a(bH var1) {
      if (var1 != null) {
         this.a.add(var1);
         ((bS)var1).a = this;
      }

      return var1;
   }

   public final ArrayList a() {
      return this.a;
   }

   public final void a(bR var1, Object var2) {
      this.put(var1, var2);
   }

   public final Object a(bR var1) {
      return this.get(var1);
   }

   public final bH b() {
      bS var1;
      (var1 = (bS)bG.a(this.a)).a = this.a;
      Iterator var2 = this.entrySet().iterator();

      while(var2.hasNext()) {
         Entry var3 = (Entry)var2.next();
         var1.put(var3.getKey(), var3.getValue());
      }

      return var1;
   }

   public final String toString() {
      return this.a.toString();
   }
}
