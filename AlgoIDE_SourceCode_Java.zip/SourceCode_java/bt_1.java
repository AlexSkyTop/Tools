import java.util.EnumSet;

public final class bt extends bc {
   private static final EnumSet a;
   private static final EnumSet f;
   private static final EnumSet g;
   private static final EnumSet h;

   public bt(bc var1) {
      super(var1);
   }

   public final bL a(aF var1, bL var2) {
      for(var1 = this.a(a); var1.a == aL.av; var1 = this.a(a)) {
         String var3 = var1.a;
         if (!super.a.a.get()) {
            var3 = var3.toLowerCase();
         }

         aH var10000;
         if (super.a.b(var3) == null) {
            (var2 = super.a.a(var3)).a(var1.a);
         } else {
            var10000 = super.a;
            aH.a(var1, aM.b);
            var2 = null;
         }

         super.a.a();
         if ((var1 = this.a(f)).a == aL.Z) {
            var1 = super.a.a();
         } else {
            var10000 = super.a;
            aH.a(var1, aM.w);
         }

         if (var2 != null) {
            var2.a(bU.c);
         }

         bP var4;
         if ((var4 = (new bu(this)).a(var1)) != null && var2 != null) {
            if (var4.a() == null) {
               var4.a(var2);
            }

            var2.a(var4);
         } else {
            this.a(g);
         }

         if ((var1 = super.a.a).a == aL.U) {
            while(var1.a == aL.U) {
               var1 = super.a.a();
            }
         }
      }

      return null;
   }

   static {
      (a = bc.d.clone()).add(aL.av);
      (f = ba.a.clone()).add(aL.Z);
      f.add(aL.U);
      g = EnumSet.of(aL.U);
      (h = bc.d.clone()).add(aL.U);
      h.add(aL.av);
   }
}
