public final class bn extends bq {
   public bn(bq var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      bH var2;
      (var2 = bG.a(bT.b)).a(bR.d, aL.y.a);
      bx var3 = new bx(this);
      String var4;
      if ((var4 = super.a.a()) != null) {
         var1.a = var4;
         var1.a = aL.av;
      }

      bH var5;
      bP var6 = (var5 = var3.b(var1)).a();
      var2.a(var5);
      var1 = super.a.a;
      bH var7 = (new bg(this)).a(var1);
      var2.a(var7);
      bP var8 = var7.a();
      if (!cb.j(var6, var8)) {
         aH var10000 = super.a;
         aH.a(var1, aM.d);
      }

      var2.a(var6);
      super.a.a(Boolean.TRUE);
      return var2;
   }
}
