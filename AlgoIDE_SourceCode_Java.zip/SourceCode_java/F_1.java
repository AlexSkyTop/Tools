import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;

public final class F implements DocumentListener {
   private final ArrayList a;
   private final N a;
   private final V a;

   public F(N var1, List var2, boolean var3) {
      this.a = var1;
      Collections.sort(var2);
      this.a = new ArrayList(var2);
      this.a(var3);
      B var4 = B.a();
      this.a = new V(var4.a(), var4.a(), var4.b(), var4.g());
      var1.getDocument().addDocumentListener(new G(this, var1));
   }

   public final void insertUpdate(DocumentEvent var1) {
      if (var1.getLength() == 1) {
         int var6 = var1.getOffset();

         try {
            String var2 = this.a.getText(0, var6 + 1);

            int var3;
            for(var3 = var6; var3 >= 0 && Character.isLetter(var2.charAt(var3)); --var3) {
            }

            if (var6 - var3 >= 2) {
               var2 = var2.substring(var3 + 1).toLowerCase();
               int var4;
               String var7;
               if ((var4 = Collections.binarySearch(this.a, var2)) < 0 && -var4 <= this.a.size() && (var7 = (String)this.a.get(-var4 - 1)).startsWith(var2)) {
                  this.a.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "commit");
                  this.a.getActionMap().put("commit", new I(this, (byte)0));
                  var2 = var7.substring(var6 - var3);
                  SwingUtilities.invokeLater(new J(this, var2, var6 + 1));
               }

            }
         } catch (BadLocationException var5) {
            var5.printStackTrace();
         }
      }
   }

   public final void removeUpdate(DocumentEvent var1) {
   }

   public final void changedUpdate(DocumentEvent var1) {
   }

   public final void a(boolean var1) {
      if (var1) {
         this.a.getDocument().addDocumentListener(this);
      } else {
         this.a.getDocument().removeDocumentListener(this);
      }
   }

   // $FF: synthetic method
   static N a(F var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static V a(F var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static List a(F var0) {
      return var0.a;
   }
}
