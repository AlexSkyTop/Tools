import java.util.HashMap;
import java.util.Iterator;

public final class ao extends at {
   public ao(at var1) {
      super(var1);
   }

   public final Object a(bH var1) {
      // $FF: Couldn't be decompiled
   }

   public final Z a(bH var1) {
      bL var2;
      String var3 = (var2 = (bL)var1.a(bR.b)).a();
      bP var4 = var2.a();
      int var11 = var2.a().a();
      Z var12 = super.a.a(var11).a(var3);
      Iterator var13 = var1.a().iterator();

      while(true) {
         while(var13.hasNext()) {
            bH var5;
            bI var6;
            if ((var6 = (var5 = (bH)var13.next()).a()) == bT.F) {
               for(Iterator var18 = var5.a().iterator(); var18.hasNext(); var4 = (bP)var4.a(cd.f)) {
                  bH var7 = (bH)var18.next();
                  bP var15;
                  int var8 = (var15 = (bP)var4.a(cd.e)).a() == cc.c ? (Integer)var15.a(cd.c) : super.a.a.get();
                  int var9 = 0;
                  Object var10;
                  ag var10000;
                  if ((var10 = this.a(var7)) instanceof Integer) {
                     var9 = (Integer)var10;
                  } else if (var10 instanceof Float) {
                     var9 = ((Float)var10).intValue();
                  } else if (var10 instanceof Character) {
                     var9 = (Character)var10;
                  } else if (a(var10)) {
                     var9 = ((String)var10).charAt(0);
                  } else {
                     var10000 = super.a;
                     ag.a(var7, af.i);
                  }

                  int var16 = (Integer)this.a(var1, var15, var9) - var8;
                  Z[] var19 = (Z[])var12.a();
                  if (var16 < var19.length) {
                     var12 = var19[var16];
                  } else {
                     var10000 = super.a;
                     ag.a(var1, af.h);
                  }
               }
            } else if (var6 == bT.G) {
               bL var14;
               String var17 = (var14 = (bL)var5.a(bR.b)).a();
               if (var12.a() instanceof Z) {
                  var12 = (Z)var12.a();
               }

               var12 = (Z)((HashMap)var12.a()).get(var17);
               var4 = var14.a();
            }
         }

         return var12;
      }
   }

   private static boolean a(Object var0) {
      return var0 instanceof String && ((String)var0).length() == 1;
   }

   private static boolean b(Object var0) {
      return var0 instanceof Character || a(var0);
   }
}
