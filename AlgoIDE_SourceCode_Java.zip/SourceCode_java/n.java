import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

final class n extends AbstractAction {
   // $FF: synthetic field
   private d a;

   n(d var1) {
      this.a = var1;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      N var12 = d.a(this.a);

      try {
         int var2 = var12.getSelectionStart();
         int var3 = var12.getSelectionEnd();
         String var4 = var12.getSelectedText();
         var2 = Math.min(var2, var3);
         Document var6 = var12.getDocument();
         if (var2 < 0) {
            throw new BadLocationException("Can't translate offset to line", -1);
         } else if (var2 > var6.getLength()) {
            throw new BadLocationException("Can't translate offset to line", var6.getLength() + 1);
         } else {
            var3 = var12.getDocument().getDefaultRootElement().getElementIndex(var2);
            String[] var15 = var4.split("\n");
            int var17 = var15.length;
            N var13 = var12;
            int var7 = 0;

            boolean var10000;
            while(true) {
               if (var7 >= var17) {
                  var10000 = false;
                  break;
               }

               int var5 = var13.a(var3 + var7);
               if (!"//".equals(var13.getText(var5, 2))) {
                  var10000 = true;
                  break;
               }

               ++var7;
            }

            boolean var16 = var10000;

            for(var17 = 0; var17 < var15.length; ++var17) {
               var2 = var12.a(var3);
               if (var16) {
                  var12.a("//", var2);
               } else {
                  int var9 = var2 + 2;
                  int var8 = var2;
                  String var18 = "";
                  if (var9 < var2) {
                     throw new IllegalArgumentException("end before start");
                  }

                  Document var14;
                  if ((var14 = var12.getDocument()) != null) {
                     try {
                        if (var14 instanceof AbstractDocument) {
                           ((AbstractDocument)var14).replace(var8, var9 - var8, var18, (AttributeSet)null);
                        } else {
                           var14.remove(var8, var9 - var8);
                           var14.insertString(var8, var18, (AttributeSet)null);
                        }
                     } catch (BadLocationException var10) {
                        throw new IllegalArgumentException(var10.getMessage());
                     }
                  }
               }

               ++var3;
            }

         }
      } catch (BadLocationException var11) {
         throw new RuntimeException(var11);
      }
   }
}
