import java.util.EnumSet;
import java.util.HashMap;

public final class bg extends bq {
   static final EnumSet a;
   private static final EnumSet d;
   private static final HashMap a;
   private static final EnumSet e;
   private static final HashMap b;
   private static final EnumSet f;
   private static final HashMap c;
   private static final EnumSet g;
   private static final HashMap d;
   private static final EnumSet h;
   private static final HashMap e;
   private static final EnumSet i;
   private static final HashMap f;

   public bg(bq var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      return this.b(var1);
   }

   private bH b(aF var1) {
      bH var2;
      bP var3 = (var2 = this.c(var1)).a();

      for(aG var4 = (var1 = super.a.a).a; var4 == aL.at; var4 = (var1 = super.a.a).a) {
         aH var10000;
         if (cb.c(var3)) {
            var3 = bV.d;
         } else {
            var10000 = super.a;
            aH.a(var1, aM.d);
         }

         bH var8;
         (var8 = bG.a(bT.D)).a(var2);
         var1 = super.a.a();
         bH var6 = this.b(var1);
         var8.a(var6);
         bP var7 = var6.a();
         var1 = super.a.a();
         bH var5 = this.b(var1);
         var8.a(var5);
         bP var9 = var5.a();
         if (cb.k(var7, var9)) {
            var3 = var7;
         } else {
            var10000 = super.a;
            aH.a(var1, aM.d);
         }

         aG var10 = super.a.a.a;
         var2 = var8;
         var8.a(var3);
      }

      return var2;
   }

   private bH c(aF var1) {
      bH var2;
      bP var3 = (var2 = this.d(var1)).a();

      for(aG var6 = super.a.a.a; d.contains((aL)var6); var6 = super.a.a.a) {
         bH var4;
         (var4 = bG.a((bI)a.get(var6))).a(var2);
         var1 = super.a.a();
         var2 = this.d(var1);
         var4.a(var2);
         bP var5 = var2.a();
         var2 = var4;
         if (cb.d(var3, var5)) {
            var3 = bV.d;
         } else {
            aH var10000 = super.a;
            aH.a(var1, aM.d);
         }

         var4.a(var3);
      }

      return var2;
   }

   private bH d(aF var1) {
      bH var2;
      bP var3 = (var2 = this.e(var1)).a();

      for(aG var6 = super.a.a.a; e.contains((aL)var6); var6 = super.a.a.a) {
         bH var4;
         (var4 = bG.a((bI)b.get(var6))).a(var2);
         var1 = super.a.a();
         var2 = this.e(var1);
         var4.a(var2);
         bP var5 = var2.a();
         var2 = var4;
         if (cb.d(var3, var5)) {
            var3 = bV.d;
         } else {
            aH var10000 = super.a;
            aH.a(var1, aM.d);
         }

         var4.a(var3);
      }

      return var2;
   }

   private bH e(aF var1) {
      bH var2;
      bP var3 = (var2 = this.f(var1)).a();

      for(aG var6 = super.a.a.a; f.contains((aL)var6); var6 = super.a.a.a) {
         bH var4;
         (var4 = bG.a((bI)c.get(var6))).a(var2);
         var1 = super.a.a();
         var2 = this.f(var1);
         var4.a(var2);
         bP var5 = var2.a();
         var2 = var4;
         if (cb.k(var3, var5)) {
            var3 = bV.d;
         } else {
            aH var10000 = super.a;
            aH.a(var1, aM.d);
         }

         var4.a(var3);
      }

      return var2;
   }

   private bH f(aF var1) {
      bH var2;
      bP var3 = (var2 = this.g(var1)).a();
      aG var6 = super.a.a.a;
      if (g.contains((aL)var6)) {
         bH var4;
         (var4 = bG.a((bI)d.get(var6))).a(var2);
         var1 = super.a.a();
         bH var5 = this.g(var1);
         var4.a(var5);
         var2 = var4;
         bP var7 = var5.a();
         if (cb.k(var3, var7)) {
            var3 = bV.d;
         } else {
            aH var10000 = super.a;
            aH.a(var1, aM.d);
         }
      }

      var2.a(var3);
      return var2;
   }

   private bH g(aF var1) {
      // $FF: Couldn't be decompiled
   }

   private bH h(aF var1) {
      // $FF: Couldn't be decompiled
   }

   private bH i(aF var1) {
      bH var2;
      bP var3 = (var2 = this.j(var1)).a();

      for(aG var6 = super.a.a.a; var6 == aL.an; var6 = super.a.a.a) {
         bH var4;
         (var4 = bG.a(bT.C)).a(var2);
         var1 = super.a.a();
         var2 = this.i(var1);
         var4.a(var2);
         bP var5 = var2.a();
         var2 = var4;
         if (cb.a(var3, var5)) {
            var3 = bV.c;
         } else if (cb.c(var3, var5)) {
            var3 = bV.c;
         } else {
            aH var10000 = super.a;
            aH.a(var1, aM.d);
         }

         var4.a(var3);
      }

      return var2;
   }

   private bH j(aF var1) {
      // $FF: Couldn't be decompiled
   }

   private bH k(aF var1) {
      // $FF: Couldn't be decompiled
   }

   static {
      a = EnumSet.of(aL.K, aL.L, aL.av, aL.aw, aL.ax, aL.ay, aL.n, aL.ai, aL.ak, aL.al);
      d = EnumSet.of(aL.p, aL.Y);
      (a = new HashMap()).put(aL.p, bT.v);
      a.put(aL.Y, bT.v);
      e = EnumSet.of(aL.a, aL.X);
      (b = new HashMap()).put(aL.a, bT.B);
      b.put(aL.X, bT.B);
      f = EnumSet.of(aL.Z, aL.ag, aL.ab, aL.af, aL.aa);
      (c = new HashMap()).put(aL.Z, bT.m);
      c.put(aL.aa, bT.m);
      c.put(aL.ag, bT.n);
      c.put(aL.af, bT.n);
      c.put(aL.ab, bT.n);
      g = EnumSet.of(aL.ac, aL.ad, aL.ah, aL.ae);
      (d = new HashMap()).put(aL.ac, bT.o);
      d.put(aL.ad, bT.p);
      d.put(aL.ah, bT.q);
      d.put(aL.ae, bT.r);
      h = EnumSet.of(aL.K, aL.L, aL.W);
      (e = new HashMap()).put(aL.K, bT.t);
      e.put(aL.L, bT.u);
      e.put(aL.W, bT.t);
      i = EnumSet.of(aL.M, aL.N, aL.f, aL.m, aL.ao);
      (f = new HashMap()).put(aL.M, bT.x);
      f.put(aL.N, bT.z);
      f.put(aL.f, bT.y);
      f.put(aL.m, bT.A);
      f.put(aL.ao, bT.A);
   }
}
