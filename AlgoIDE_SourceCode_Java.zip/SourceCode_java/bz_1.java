public final class bz extends aK {
   public bz(aE var1, aM var2, String var3) {
      super(var1);
      super.a = var3;
      super.a = aL.az;
      super.a = var2;
   }

   public final void a() {
   }
}
