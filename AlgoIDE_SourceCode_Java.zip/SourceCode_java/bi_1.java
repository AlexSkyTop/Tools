import java.util.EnumSet;

public final class bi extends bq {
   private static final EnumSet a;
   private static final EnumSet d;

   public bi(bq var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      aF var2 = var1 = super.a.a();
      bH var3 = bG.a(bT.a);
      bH var4 = bG.a(bT.c);
      bH var5 = bG.a(bT.d);
      bH var6;
      bP var7 = (var6 = (new aP(this)).a(var1, true)).a();
      a(var6, var2);
      aH var10000;
      if (!cb.a(var7) && var7.a() != cc.b) {
         var10000 = super.a;
         aH.a(var1, aM.d);
      }

      var3.a(var6);
      var3.a(var4);
      if ((var1 = this.a(a)).a == aL.B) {
         var1 = super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var1, aM.P);
      }

      bH var8 = (new bg(this)).a(var1);
      var1 = super.a.a;
      int var9 = 1;
      if (var1.a == aL.z) {
         var1 = super.a.a();
         Object var11;
         if ((var11 = (new ba(this)).a()) instanceof Integer) {
            var9 = (Integer)var11;
         } else {
            var10000 = super.a;
            aH.a(var1, aM.l);
         }
      }

      bH var10;
      (var10 = bG.a(var9 > 0 ? bT.q : bT.o)).a(bV.d);
      bH var14 = (bH)var6.a().get(0);
      var10.a(var14.b());
      var10.a(var8);
      bP var13 = var8.a();
      if (!cb.j(var7, var13)) {
         var10000 = super.a;
         aH.a(var1, aM.d);
      }

      var5.a(var10);
      var4.a(var5);
      if ((var1 = this.a(d)).a == aL.g) {
         var1 = super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var1, aM.s);
      }

      var5 = bG.a(bT.a);
      var4.a(var5);
      (new bq(this)).a(var1, var5, aL.v);
      if ((var1 = super.a.a).a == aL.v) {
         super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var1, aM.N);
      }

      bH var12;
      (var12 = bG.a(bT.b)).a(var7);
      var12.a(var14.b());
      (var5 = bG.a(bT.t)).a(bV.b);
      var5.a(var14.b());
      (var6 = bG.a(bT.H)).a(bR.c, var9);
      var6.a(bV.b);
      var5.a(var6);
      var12.a(var5);
      var4.a(var12);
      a(var12, var2);
      return var3;
   }

   static {
      (a = bg.a.clone()).add(aL.B);
      a.addAll(bq.c);
      (d = bq.b.clone()).add(aL.g);
      d.addAll(bq.c);
   }
}
