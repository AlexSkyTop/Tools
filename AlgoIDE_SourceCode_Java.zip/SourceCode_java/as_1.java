import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public final class as extends at {
   private final HashMap a = new HashMap();

   public as(at var1) {
      super(var1);
   }

   public final Object a(bH var1) {
      HashMap var2;
      if ((var2 = (HashMap)this.a.get(var1)) == null) {
         HashMap var3 = new HashMap();
         ArrayList var11;
         int var4 = (var11 = var1.a()).size();
         if (((bH)var11.get(var4 - 1)).a() == bT.l) {
            --var4;
         }

         for(int var5 = 1; var5 < var4; ++var5) {
            bH var6;
            bH var7 = (bH)(var6 = (bH)var11.get(var5)).a().get(0);
            var6 = (bH)var6.a().get(1);

            Object var9;
            for(Iterator var15 = var7.a().iterator(); var15.hasNext(); var3.put(var9, var6)) {
               bH var8;
               var9 = (var8 = (bH)var15.next()).a(bR.c);
               if (var8.a() == bT.J && ((String)var9).length() == 1) {
                  var9 = ((String)var9).charAt(0);
               }
            }
         }

         var2 = var3;
         this.a.put(var1, var3);
      }

      ArrayList var10;
      bH var12 = (bH)(var10 = var1.a()).get(0);
      Object var14;
      if ((var14 = (new ao(this)).a(var12)) instanceof String && ((String)var14).length() == 1) {
         var14 = ((String)var14).charAt(0);
      }

      bH var13 = (bH)var2.get(var14);
      var1 = (bH)var10.get(var10.size() - 1);
      if (var13 != null) {
         (new at(this)).a(var13);
      } else if (var1.a() == bT.l) {
         var13 = (bH)var1.a().get(0);
         (new at(this)).a(var13);
      }

      ++a;
      return null;
   }
}
