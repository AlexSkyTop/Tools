public final class ac {
   public static ad a(bK var0) {
      return new ax(var0);
   }

   public static Z a(Object var0) {
      return new aw(var0);
   }
}
