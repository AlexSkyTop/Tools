import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

final class g extends AbstractAction {
   // $FF: synthetic field
   private d a;

   g(d var1) {
      this.a = var1;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      d.c(this.a);
   }
}
