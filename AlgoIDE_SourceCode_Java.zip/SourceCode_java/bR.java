public enum bR {
   a,
   b,
   c,
   d;
}
