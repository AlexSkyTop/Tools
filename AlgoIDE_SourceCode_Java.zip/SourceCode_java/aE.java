import java.io.BufferedReader;

public final class aE {
   public final BufferedReader a;
   public String a;
   int a = 0;
   public int b = -2;

   public aE(BufferedReader var1) {
      this.a = var1;
   }

   public final char a() {
      if (this.b == -2) {
         this.a();
         return this.b();
      } else if (this.a == null) {
         return '\u0000';
      } else if (this.b != -1 && this.b != this.a.length()) {
         if (this.b > this.a.length()) {
            this.a();
            return this.b();
         } else {
            return this.a.charAt(this.b);
         }
      } else {
         return '\n';
      }
   }

   public final char b() {
      ++this.b;
      return this.a();
   }

   public final char c() {
      this.a();
      if (this.a == null) {
         return '\u0000';
      } else {
         int var1;
         return (var1 = this.b + 1) < this.a.length() ? this.a.charAt(var1) : '\n';
      }
   }

   private void a() {
      this.a = this.a.readLine();
      this.b = -1;
      if (this.a != null) {
         ++this.a;
      }

   }
}
