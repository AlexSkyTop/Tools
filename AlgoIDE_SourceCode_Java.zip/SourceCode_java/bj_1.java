import java.util.EnumSet;

public final class bj extends bq {
   private static final EnumSet a;

   public bj(bq var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      bH var7 = bG.a(bT.g);
      bH var3 = var7;
      bj var2 = this;

      while(true) {
         aF var4 = var2.a.a();
         bH var5 = (new bg(var2)).a(var4);
         var3.a(var5);
         aH var10000;
         if (!cb.c(var5.a())) {
            var10000 = var2.a;
            aH.a(var4, aM.d);
         }

         if ((var4 = var2.a(a)).a == aL.A) {
            var4 = var2.a.a();
         } else {
            var10000 = var2.a;
            aH.a(var4, aM.C);
         }

         var5 = bG.a(bT.a);
         var3.a(var5);
         bq var6;
         (var6 = new bq(var2)).a(var4, var5, aL.h);
         if ((var4 = var2.a.a).a != aL.I) {
            if (var4.a == aL.h) {
               var4 = var2.a.a();
               var5 = bG.a(bT.a);
               var3.a(var5);
               var6.a(var4, var5, aL.u);
               var4 = var2.a.a;
            }

            if (var4.a == aL.u) {
               var2.a.a();
            } else {
               var10000 = var2.a;
               aH.a(var4, aM.O);
            }

            return var7;
         }

         var5 = bG.a(bT.g);
         var3.a(var5);
         var3 = var5;
         var2 = var2;
      }
   }

   static {
      (a = bq.b.clone()).add(aL.A);
      a.addAll(bq.c);
   }
}
