import java.util.ArrayList;
import java.util.Iterator;

public final class ar extends at {
   public ar(at var1) {
      super(var1);
   }

   public final Object a(bH var1) {
      boolean var2 = false;
      bH var3 = null;
      ArrayList var4 = var1.a();
      ao var5 = new ao(this);
      at var6 = new at(this);
      int var7 = 0;

      while(!var2) {
         ++a;
         ++var7;
         if (var7 >= 10000) {
            ag var10000 = super.a;
            ag.a(var1, af.k);
            break;
         }

         if (super.a.c.get()) {
            throw new InterruptedException();
         }

         Iterator var8 = var4.iterator();

         while(var8.hasNext()) {
            bH var9;
            if ((bT)(var9 = (bH)var8.next()).a() == bT.d) {
               if (var3 == null) {
                  var3 = (bH)var9.a().get(0);
               }

               var2 = (Boolean)var5.a(var3);
            } else {
               if (super.a.a()) {
                  return null;
               }

               var6.a(var9);
            }

            if (var2) {
               break;
            }
         }
      }

      return null;
   }
}
