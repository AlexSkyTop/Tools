import java.util.ArrayList;
import java.util.Iterator;

public final class al extends ak {
   private ao a;

   public al(ak var1) {
      super(var1);
   }

   public final Object a(bH var1) {
      // $FF: Couldn't be decompiled
   }

   private Object a(bH var1, bJ var2) {
      bH var10000 = var1.a().size() > 0 ? (bH)var1.a().get(0) : null;
      bH var3 = var10000;
      ag var22;
      if (var10000 != null) {
         ArrayList var16 = var3.a();
         this.a(new cf(ci.f, (Object)null));
         Iterator var17 = var16.iterator();

         while(var17.hasNext()) {
            bH var4;
            bP var5;
            bP var6 = (var5 = (var4 = (bH)var17.next()).a()).a();
            Z var7 = this.a.a(var4);

            Object var18;
            try {
               aF var8;
               if (var6 == bV.b) {
                  var8 = super.a.a();
                  if (super.a.c.get()) {
                     throw new InterruptedException();
                  }

                  var18 = this.a(var8, var6);
               } else if (var6 == bV.c) {
                  var8 = super.a.a();
                  if (super.a.c.get()) {
                     throw new InterruptedException();
                  }

                  var18 = this.a(var8, var6);
               } else {
                  String var9;
                  if (var6 == bV.d) {
                     var8 = super.a.a();
                     if (super.a.c.get()) {
                        throw new InterruptedException();
                     }

                     if (var8.a != aL.av) {
                        throw new Exception();
                     }

                     Boolean var23;
                     if ((var9 = var8.a).equalsIgnoreCase("vrai")) {
                        var23 = Boolean.TRUE;
                     } else {
                        if (!var9.equalsIgnoreCase("faux")) {
                           throw new Exception();
                        }

                        var23 = Boolean.FALSE;
                     }

                     var18 = var23;
                  } else if (var6 == bV.e) {
                     var8 = super.a.a();
                     if (super.a.c.get()) {
                        throw new InterruptedException();
                     }

                     if ((var9 = var8.a) == null || var9.length() > 1) {
                        throw new Exception();
                     }

                     char var19;
                     if ((var19 = var9.charAt(0)) == '\n' || var19 == 0) {
                        var19 = ' ';
                     }

                     var18 = var19;
                  } else {
                     if (!var5.a()) {
                        throw new Exception();
                     }

                     do {
                        do {
                           var18 = super.a.a.a.readLine();
                           if (super.a.c.get()) {
                              throw new InterruptedException();
                           }
                        } while(var18 == null);
                     } while(((String)var18).length() == 0);
                  }
               }
            } catch (Exception var14) {
               var22 = super.a;
               ag.a(var1, af.f);
               if (var5 == bV.c) {
                  var18 = 0.0F;
               } else if (var5 == bV.e) {
                  var18 = ' ';
               } else if (var5 == bV.d) {
                  var18 = Boolean.FALSE;
               } else {
                  var18 = 0;
               }
            }

            var18 = this.a(var1, var5, var18);
            if (var5.a()) {
               Object var10 = this.a(var1, var5, var18);
               if (var5.a()) {
                  String var21;
                  int var11 = (var21 = (String)var10).length();
                  bP var12;
                  (var12 = (bP)var5.a(cd.e)).a(cd.c, super.a.a.get());
                  var12.a(cd.d, var11 + super.a.a.get() - 1);
                  var5.a(cd.g, var11);
                  var7.a(this.a((Object)a((bP)var5, (Object)var21), (bH)var1));
               }
            } else {
               var7.a(var18);
            }

            bL var20 = (bL)var4.a(bR.b);
            this.a(var1, var20.a(), var18);
         }
      }

      if (var2 == bW.e) {
         try {
            aE var15;
            if ((var15 = super.a.a).a != null) {
               var15.b = var15.a.length() + 1;
            }
         } catch (Exception var13) {
            var22 = super.a;
            ag.a(var1, af.f);
         }
      }

      this.a(new cf(ci.g, (Object)null));
      return null;
   }

   private Number a(aF var1, bP var2) {
      aG var3 = var1.a;
      aG var4 = null;
      if (var3 == aL.K || var3 == aL.L) {
         var4 = var3;
         var3 = (var1 = super.a.a()).a;
      }

      if (var3 == aL.aw) {
         Integer var6 = var4 == aL.L ? -(Integer)var1.a : (Integer)var1.a;
         return (Number)(var2 == bV.b ? var6 : ((Integer)var6).floatValue());
      } else if (var3 == aL.ax) {
         Float var5 = var4 == aL.L ? -(Float)var1.a : (Float)var1.a;
         return (Number)(var2 == bV.c ? var5 : ((Float)var5).intValue());
      } else {
         throw new Exception();
      }
   }

   private Number a(bH var1) {
      ag var10000;
      bH var2;
      if ((var2 = (bH)var1.a().get(0)) != null) {
         var2 = (bH)var2.a().get(0);
         Object var5;
         if ((var5 = this.a.a(var2)) instanceof String) {
            try {
               return Float.parseFloat((String)var5);
            } catch (NumberFormatException var4) {
               var10000 = super.a;
               ag.a(var1, af.e);
            }
         } else {
            if (!(var5 instanceof Character)) {
               var10000 = super.a;
               ag.a(var1, af.d);
               return 0;
            }

            try {
               return Float.parseFloat(Character.toString((Character)var5));
            } catch (NumberFormatException var3) {
               var10000 = super.a;
               ag.a(var1, af.e);
            }
         }
      }

      var10000 = super.a;
      ag.a(var1, af.d);
      return 0;
   }
}
