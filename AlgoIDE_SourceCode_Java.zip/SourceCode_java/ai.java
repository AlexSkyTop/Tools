import java.util.ArrayList;

public final class ai extends at {
   public ai(at var1) {
      super(var1);
   }

   public final Object a(bH var1) {
      ArrayList var2;
      bH var3 = (bH)(var2 = var1.a()).get(0);
      bH var9 = (bH)var2.get(1);
      bL var4 = (bL)var3.a(bR.b);
      ao var5 = new ao(this);
      bP var6 = var3.a();
      bP var7 = var9.a().a();
      Z var8 = var5.a(var3);
      Object var10 = var5.a(var9);
      if (var7.a() && var10 instanceof String) {
         var7.a(cd.g, ((String)var10).length());
      }

      this.a(var1, var4, var8, var6, var10, var7);
      var3.a(bR.b, var4);
      ++a;
      return var1.a(bR.d);
   }

   protected final void a(bH var1, bL var2, Z var3, bP var4, Object var5, bP var6) {
      if (var3 == null) {
         ag var10000 = super.a;
         ag.a(var1, af.j);
      } else {
         var5 = this.a(var1, var4, var5);
         if (var4 == bV.c && var6 == bV.b) {
            var3.a(((Integer)var5).floatValue());
         } else if (var4.a() && var6 == bV.e) {
            String var15;
            if (var5 instanceof Character) {
               var15 = String.valueOf(var5);
            } else {
               var15 = (String)var5;
            }

            var3.a(this.a(a(var4, var15), var1));
         } else {
            int var12;
            if (var4.a() && var6.a()) {
               var12 = (Integer)var6.a(cd.g);
               String var14 = (String)var5;
               var3.a(this.a(a(var6, var14), var1));
               var4.a(cd.g, var12);
               bP var11;
               (var11 = (bP)var4.a(cd.e)).a(cd.c, super.a.a.get());
               var11.a(cd.d, var12 + super.a.a.get() - 1);
            } else if (var4 == bV.b && var6 == bV.e) {
               if (var5 instanceof String) {
                  var12 = ((String)var5).charAt(0);
               } else if (var5 instanceof Integer) {
                  var12 = (Integer)var5;
               } else {
                  var12 = (Character)var5;
               }

               var3.a(this.a(a(var4, var12), var1));
            } else if (var4 == bV.e && var6 == bV.b) {
               char var13 = (char)(Integer)var5;
               var3.a(this.a(a(var4, var13), var1));
            } else if (var4 == bV.b && var6 == bV.c) {
               var12 = (int)(Float)var5;
               var3.a(this.a(a(var4, var12), var1));
            } else if (var4.a() == cc.d && var6.a() == cc.f) {
               Z[] var7 = (Z[])var3.a();
               ArrayList var8 = (ArrayList)var5;
               var4 = (bP)var4.a(cd.f);
               var6 = (bP)var6.a(cd.f);
               int var10 = Math.min(var7.length, var8.size());

               for(int var9 = 0; var9 < var10; ++var9) {
                  this.a(var1, var2, var7[var9], var4, var8.get(var9), var6);
               }
            } else if (var3.a() instanceof Z) {
               var3 = (Z)var3.a();
               if (var5 instanceof Z) {
                  var5 = ((Z)var5).a();
               }

               var3.a(this.a(a(var4, var5), var1));
            } else {
               if (var5 instanceof Z) {
                  var5 = ((Z)var5).a();
               }

               var3.a(this.a(a(var4, var5), var1));
            }
         }

         this.a(var1, var2.a(), var5);
      }
   }
}
