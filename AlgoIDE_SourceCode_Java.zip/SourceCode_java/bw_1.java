import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Iterator;

public final class bw extends bc {
   bU a;
   private static EnumSet f;
   private static EnumSet g;
   private static final EnumSet h;
   private static final EnumSet i;
   static final EnumSet a;
   private static final EnumSet j;

   public bw(aI var1) {
      super(var1);
   }

   public final bL a(aF var1, bL var2) {
      for(var1 = this.a(f); var1.a == aL.av; var1 = this.a(f)) {
         this.a(h, i);
         if ((var1 = super.a.a).a == aL.U) {
            while(var1.a == aL.U) {
               var1 = super.a.a();
            }
         }
      }

      return null;
   }

   protected final ArrayList a(EnumSet var1, EnumSet var2) {
      ArrayList var3 = new ArrayList();

      aF var4;
      do {
         var4 = this.a(g);
         bL var6;
         if ((var6 = this.a(var4)) != null) {
            var3.add(var6);
         }

         aH var10000;
         aG var5;
         if ((var5 = (var4 = this.a(var2)).a) == aL.T) {
            var4 = super.a.a();
            if (var1.contains((aL)var4.a)) {
               var10000 = super.a;
               aH.a(var4, aM.x);
            }
         } else if (g.contains((aL)var5)) {
            var10000 = super.a;
            aH.a(var4, aM.r);
         }
      } while(!var1.contains((aL)var4.a));

      if (this.a != bU.h) {
         bP var8 = this.a();

         for(Iterator var7 = var3.iterator(); var7.hasNext(); var8 = this.a(var8)) {
            ((bL)var7.next()).a(var8);
         }
      }

      return var3;
   }

   private bP a(bP var1) {
      if (var1.a() == cc.d) {
         bP var2 = bN.a(cc.d);
         bP var3;
         (var3 = bN.a(cc.c)).a(cd.b, bV.b);
         bP var4;
         int var5 = (Integer)(var4 = (bP)var1.a(cd.e)).a(cd.c);
         int var7 = (Integer)var4.a(cd.d);
         var3.a(cd.c, var5);
         var3.a(cd.d, var7);
         var2.a(cd.e, var3);
         int var6 = (Integer)var1.a(cd.g);
         var2.a(cd.g, var6);
         var1 = (bP)var1.a(cd.f);
         var2.a(cd.f, this.a(var1));
         return var2;
      } else {
         return var1;
      }
   }

   private bL a(aF var1) {
      bL var2 = null;
      aH var10000;
      if (var1.a == aL.av) {
         String var3 = var1.a;
         if (!super.a.a.get()) {
            var3 = var3.toLowerCase();
         }

         var2 = super.a.b(var3);
         if (aL.a.contains(var3.toLowerCase())) {
            var10000 = super.a;
            aH.a(var1, aM.P);
         }

         if (var2 == null) {
            (var2 = super.a.a(var3)).a(this.a);
            var2.a(var1.a);
         } else {
            var10000 = super.a;
            aH.a(var1, aM.b);
         }

         super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var1, aM.x);
      }

      return var2;
   }

   protected final bP a() {
      aF var1;
      if ((var1 = this.a(j)).a == aL.V) {
         var1 = super.a.a();
      } else {
         aH var10000 = super.a;
         aH.a(var1, aM.p);
      }

      return (new bu(this)).a(var1);
   }

   static {
      (f = bc.d.clone()).add(aL.av);
      f.add(aL.i);
      f.add(aL.U);
      f.add(aL.U);
      g = EnumSet.of(aL.av, aL.T);
      (h = EnumSet.of(aL.V, aL.U)).addAll(bc.d);
      i = EnumSet.of(aL.T, aL.V, aL.av, aL.U);
      (a = bc.e.clone()).add(aL.av);
      a.add(aL.U);
      j = EnumSet.of(aL.V, aL.U);
   }
}
