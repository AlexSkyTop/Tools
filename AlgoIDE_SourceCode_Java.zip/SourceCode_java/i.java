import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

final class i extends AbstractAction {
   // $FF: synthetic field
   private d a;

   i(d var1) {
      this.a = var1;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
   }
}
