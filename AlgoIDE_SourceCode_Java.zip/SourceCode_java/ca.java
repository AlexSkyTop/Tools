import java.util.ArrayList;

public final class ca extends ArrayList implements bM {
   private int a = 0;
   private bL a;

   public ca() {
      this.add(new bY(this.a));
   }

   public final void a(bL var1) {
      this.a = var1;
   }

   public final bL a() {
      return this.a;
   }

   public final bK a() {
      bY var1 = new bY(++this.a);
      this.add(var1);
      return var1;
   }

   public final bK b() {
      bK var1 = (bK)this.get(this.a);
      this.remove(this.a--);
      return var1;
   }

   public final bL a(String var1) {
      return ((bK)this.get(this.a)).a(var1);
   }

   public final bL b(String var1) {
      return ((bK)this.get(this.a)).b(var1);
   }

   public final bL c(String var1) {
      bL var2 = null;

      for(int var3 = this.a; var3 >= 0 && var2 == null; --var3) {
         var2 = ((bK)this.get(var3)).b(var1);
      }

      return var2;
   }

   public final String a() {
      String var1 = null;

      for(int var2 = this.a; var2 >= 0 && var1 == null; --var2) {
         var1 = ((bK)this.get(var2)).a();
      }

      return var1;
   }

   public final void a(String var1) {
      ((bK)this.get(this.a)).a(var1);
   }

   public final Boolean a() {
      Boolean var1 = null;

      for(int var2 = this.a; var2 >= 0 && var1 == null; --var2) {
         var1 = ((bK)this.get(var2)).a();
      }

      return var1;
   }

   public final void a(Boolean var1) {
      ((bK)this.get(this.a)).a(var1);
   }
}
