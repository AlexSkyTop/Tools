// $FF: synthetic class
final class be {
   // $FF: synthetic field
   static final int[] a = new int[aL.values().length];

   static {
      try {
         a[aL.r.ordinal()] = 1;
      } catch (NoSuchFieldError var2) {
      }

      try {
         a[aL.q.ordinal()] = 2;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[aL.k.ordinal()] = 3;
      } catch (NoSuchFieldError var0) {
      }
   }
}
