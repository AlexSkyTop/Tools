import java.util.Iterator;

public final class X {
   public static Object a(bP var0, bH var1) {
      while((var0 = var0.a()) != bV.b) {
         if (var0 == bV.c) {
            return 0.0F;
         }

         if (var0 == bV.d) {
            return Boolean.FALSE;
         }

         if (var0 == bV.e) {
            return ' ';
         }

         if (var0.a() == cc.d) {
            var0 = (bP)var0.a(cd.f);
         } else {
            if (var0.a() != cc.e) {
               return ' ';
            }

            bK var10000 = (bK)var0.a(cd.h);
            bP var2 = ((bL)var1.a(bR.b)).a();
            Iterator var4 = var1.a().iterator();

            while(var4.hasNext()) {
               bH var3;
               if ((var3 = (bH)var4.next()).a() == bT.G) {
                  var2 = ((bL)var3.a(bR.b)).a();
               }
            }

            var0 = var2;
         }
      }

      return 0;
   }
}
