import java.awt.event.ActionEvent;
import java.util.Map.Entry;
import javax.swing.AbstractAction;

final class E extends AbstractAction {
   // $FF: synthetic field
   private Entry a;
   // $FF: synthetic field
   private D a;

   E(D var1, Entry var2) {
      this.a = var1;
      this.a = var2;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      D.a(this.a).replaceSelection(String.valueOf(this.a.getKey()) + this.a.getValue());
      int var2 = D.a(this.a).getCaretPosition();
      D.a(this.a).setCaretPosition(var2 - 1);
   }
}
