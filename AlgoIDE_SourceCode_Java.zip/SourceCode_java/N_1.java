import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextPane;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Highlighter;
import javax.swing.text.Highlighter.Highlight;

public final class N extends JTextPane implements DocumentListener {
   public final Color a = new Color(16751001);

   public N(P var1, int var2) {
      super(var1);
      this.a(var2);
      this.getInputMap().put(KeyStroke.getKeyStroke("TAB"), "insertTab");
      this.getActionMap().put("insertTab", new O(this));
   }

   private void a() {
      Highlighter var1;
      Highlight[] var2;
      int var3 = (var2 = (var1 = this.getHighlighter()).getHighlights()).length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Highlight var5 = var2[var4];
         var1.removeHighlight(var5);
      }

      this.getDocument().addDocumentListener(this);
   }

   public final void a(int var1) {
      this.setFont(new Font("Dialog", 0, var1));
   }

   public final void b(int var1) {
      this.setFont(new Font("Dialog", 0, Math.max(Math.min(this.getFont().getSize() + var1, 60), 6)));
   }

   private int a() {
      return this.getDocument().getDefaultRootElement().getElementCount();
   }

   public final int a(int var1) {
      int var2 = this.a();
      if (var1 < 0) {
         throw new BadLocationException("Negative line", -1);
      } else if (var1 >= var2) {
         throw new BadLocationException("No such line", this.getDocument().getLength() + 1);
      } else {
         return this.getDocument().getDefaultRootElement().getElement(var1).getStartOffset();
      }
   }

   public final void a(String var1, int var2) {
      Document var3;
      if ((var3 = this.getDocument()) != null) {
         try {
            var3.insertString(var2, var1, (AttributeSet)null);
         } catch (BadLocationException var4) {
            throw new IllegalArgumentException(var4.getMessage());
         }
      }
   }

   public final void insertUpdate(DocumentEvent var1) {
      this.a();
   }

   public final void removeUpdate(DocumentEvent var1) {
      this.a();
   }

   public final void changedUpdate(DocumentEvent var1) {
   }
}
