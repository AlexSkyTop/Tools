import java.awt.GridLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class C extends JDialog {
   private final B a = B.a();

   public C(d var1, String var2) {
      super(var1, var2, true);
      this.setSize(350, 220);
      JTabbedPane var15;
      JTabbedPane var10000 = var15 = new JTabbedPane();
      JPanel var4;
      (var4 = new JPanel(false)).setLayout(new GridLayout(5, 2));
      JLabel var5 = new JLabel("Text size");
      JLabel var6 = new JLabel("Auto indent");
      JLabel var7 = new JLabel("Auto pair");
      JLabel var8 = new JLabel("Highlight current line");
      JLabel var9 = new JLabel("Autocomplete code");
      JComboBox var10;
      (var10 = new JComboBox(new Integer[]{6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 18, 20, 24, 28, 32, 36, 40, 50, 60})).setSelectedItem(this.a.b());
      var10.addActionListener((var2x) -> {
         Object var3;
         if ((var3 = var10.getSelectedItem()) != null) {
            int var4 = (Integer)var3;
            this.a.a.putInt("TEXT_SIZE_KEY", var4);
         }

      });
      JCheckBox var11;
      (var11 = new JCheckBox()).setSelected(this.a.c());
      var11.addItemListener((var1x) -> {
         boolean var2 = var1x.getStateChange() == 1;
         this.a.a.putBoolean("AUTO_INDENT_KEY", var2);
      });
      JCheckBox var12;
      (var12 = new JCheckBox()).setSelected(this.a.d());
      var12.addItemListener((var1x) -> {
         boolean var2 = var1x.getStateChange() == 1;
         this.a.a.putBoolean("AUTO_PAIR_KEY", var2);
      });
      JCheckBox var13;
      (var13 = new JCheckBox()).setSelected(this.a.e());
      var13.addItemListener((var1x) -> {
         boolean var2 = var1x.getStateChange() == 1;
         this.a.a.putBoolean("HIGHLIGHT_CURRENT_LINE_KEY", var2);
      });
      JCheckBox var14;
      (var14 = new JCheckBox()).setSelected(this.a.f());
      var14.addItemListener((var1x) -> {
         boolean var2 = var1x.getStateChange() == 1;
         this.a.a.putBoolean("AUTO_COMPLETE_KEY", var2);
      });
      var4.add(var5);
      var4.add(var10);
      var4.add(var6);
      var4.add(var11);
      var4.add(var7);
      var4.add(var12);
      var4.add(var8);
      var4.add(var13);
      var4.add(var9);
      var4.add(var14);
      var10000.addTab("General", var4);
      (var4 = new JPanel(false)).setLayout(new GridLayout(5, 2));
      var5 = new JLabel("Start array index");
      var6 = new JLabel("Use default values");
      var7 = new JLabel("Case sensitive");
      var8 = new JLabel("Auto line break at end of 'ecrire'");
      JComboBox var16;
      (var16 = new JComboBox(new Integer[]{0, 1})).setSelectedItem(this.a.a());
      var16.addActionListener((var2x) -> {
         Object var3;
         if ((var3 = var16.getSelectedItem()) != null) {
            int var4 = (Integer)var3;
            this.a.a.putInt("START_INDEX_ARRAY_KEY", var4);
         }

      });
      JCheckBox var17;
      (var17 = new JCheckBox()).setSelected(this.a.b());
      var17.addItemListener((var1x) -> {
         boolean var2 = var1x.getStateChange() == 1;
         this.a.a.putBoolean("USE_DEFAULT_VALUES_KEY", var2);
      });
      (var11 = new JCheckBox()).setSelected(this.a.a());
      var11.addItemListener((var1x) -> {
         boolean var2 = var1x.getStateChange() == 1;
         this.a.a.putBoolean("CASE_SENSITIVE_KEY", var2);
      });
      (var12 = new JCheckBox()).setSelected(this.a.g());
      var12.addItemListener((var1x) -> {
         boolean var2 = var1x.getStateChange() == 1;
         this.a.a.putBoolean("WITH_NEW_LINE_KEY", var2);
      });
      var4.add(var5);
      var4.add(var16);
      var4.add(var6);
      var4.add(var17);
      var4.add(var7);
      var4.add(var11);
      var4.add(var8);
      var4.add(var12);
      var15.addTab("Interpreter", var4);
      this.setContentPane(var15);
      this.setLocationRelativeTo(var1);
      this.setDefaultCloseOperation(2);
      this.setVisible(true);
   }
}
