// $FF: synthetic class
final class au {
   // $FF: synthetic field
   static final int[] a = new int[bT.values().length];

   static {
      try {
         a[bT.a.ordinal()] = 1;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a[bT.b.ordinal()] = 2;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a[bT.c.ordinal()] = 3;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a[bT.g.ordinal()] = 4;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a[bT.h.ordinal()] = 5;
      } catch (NoSuchFieldError var2) {
      }

      try {
         a[bT.e.ordinal()] = 6;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[bT.k.ordinal()] = 7;
      } catch (NoSuchFieldError var0) {
      }
   }
}
