import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;

final class G implements DocumentListener {
   // $FF: synthetic field
   private N a;
   // $FF: synthetic field
   private F a;

   G(F var1, N var2) {
      this.a = var1;
      this.a = var2;
      super();
   }

   public final void insertUpdate(DocumentEvent var1) {
      try {
         (new Thread(new H(this.a, this.a.getText(0, this.a.getCaretPosition())))).start();
      } catch (BadLocationException var2) {
         throw new RuntimeException(var2);
      }
   }

   public final void removeUpdate(DocumentEvent var1) {
   }

   public final void changedUpdate(DocumentEvent var1) {
   }
}
