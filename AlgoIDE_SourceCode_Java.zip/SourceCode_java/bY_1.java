import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;

public final class bY extends TreeMap implements bK {
   private final int a;
   private String a;
   private Boolean a;

   public bY(int var1) {
      this.a = var1;
      this.a = null;
      this.a = null;
   }

   public final int a() {
      return this.a;
   }

   public final bL a(String var1) {
      bX var2 = new bX(var1, this);
      this.put(var1, var2);
      return var2;
   }

   public final bL b(String var1) {
      return (bL)this.get(var1);
   }

   public final ArrayList a() {
      Iterator var1 = this.values().iterator();
      ArrayList var2 = new ArrayList(this.size());

      while(var1.hasNext()) {
         var2.add(var1.next());
      }

      return var2;
   }

   public final String a() {
      return this.a;
   }

   public final void a(String var1) {
      this.a = var1;
   }

   public final Boolean a() {
      return this.a;
   }

   public final void a(Boolean var1) {
      this.a = var1;
   }
}
