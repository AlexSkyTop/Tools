public enum aM {
   a("Constante CAS réutilisée"),
   b("Identifiant redéfini"),
   c("Identifiant indéfini"),
   d("Types incompatibles"),
   e("Caractère invalide"),
   f("Constante invalide"),
   g("Champ invalide"),
   h("Utilisation d’un identifiant non valide"),
   i("Type d’indice non valide"),
   j("Nombre invalide"),
   k("Type d'intervalle invalide"),
   l("Type invalide"),
   m("Paramètre VAR non valide"),
   n("Limite minimale supérieure à la limite maximale"),
   o("Manque DEBUT"),
   p("Manque :"),
   q("Manque <-"),
   r("Manque ,"),
   s("Manque FAIRE"),
   t("Manque .."),
   u("Manque FIN"),
   v("Manque FINCAS ou FINSELON"),
   w("Manque ="),
   x("Identificateur manquant"),
   y("Manque ["),
   z("Manque DE"),
   A("Manque ]"),
   B("Manque )"),
   C("Manque ALORS"),
   D("Manque JUSQUA"),
   S("Manque ;"),
   E("Pas un identifiant constant"),
   F("Pas un identifiant de type"),
   G("Entier hors plage"),
   H("Réel hors plage"),
   I("Trop d’indices"),
   J("Fin de fichier inattendue"),
   K("Mot inattendu rencontré"),
   L("Nombre de paramètres erronés"),
   M("Manque FINTANTQUE"),
   N("Manque FINPOUR"),
   O("Manque FINSI"),
   T("Manque À"),
   P("Fonction prédéfinie avec le même nom"),
   U("Tableau d'éléments incompatibles"),
   Q("L'emplacement de la définition n'est pas valide"),
   R("Manque RETOURNER");

   private final String a;

   private aM(String var3) {
      this.a = var3;
   }

   public final String toString() {
      return this.a;
   }
}
