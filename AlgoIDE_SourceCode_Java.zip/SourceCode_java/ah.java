public interface ah {
   Y a(int var1);

   void a();

   void a(av var1);

   boolean a();

   void b();
}
