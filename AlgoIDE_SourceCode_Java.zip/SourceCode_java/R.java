import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.JTextComponent;
import javax.swing.text.TextAction;

public final class R extends TextAction {
   public R() {
      super("insert-break");
   }

   public final void actionPerformed(ActionEvent var1) {
      JTextComponent var9;
      if ((var9 = this.getTextComponent(var1)) != null) {
         if (var9.isEditable() && var9.isEnabled()) {
            try {
               Document var2;
               Element var3 = (var2 = var9.getDocument()).getDefaultRootElement();
               int var4 = var9.getSelectionStart();
               int var5 = var3.getElementIndex(var4);
               int var6 = var3.getElement(var5).getStartOffset();
               int var11 = var3.getElement(var5).getEndOffset() - var6;
               String var10 = var2.getText(var6, var11);

               char var7;
               for(var5 = 0; var5 < var11 && ((var7 = var10.charAt(var5)) == ' ' || var7 == '\t'); ++var5) {
               }

               if (var4 - var6 > var5) {
                  var9.replaceSelection("\n" + var10.substring(0, var5));
               } else {
                  var9.replaceSelection("\n");
               }
            } catch (BadLocationException var8) {
            }
         } else {
            UIManager.getLookAndFeel().provideErrorFeedback(var9);
         }
      }
   }
}
