public interface K {
   void onCurrentFileChange(String var1, String var2);
}
