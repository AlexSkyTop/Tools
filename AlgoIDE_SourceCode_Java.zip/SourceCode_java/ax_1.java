import java.util.HashMap;
import java.util.Iterator;

public final class ax extends HashMap implements ad {
   private bK a;

   public ax(bK var1) {
      this.a = var1;
      Iterator var4 = var1.a().iterator();

      while(true) {
         while(var4.hasNext()) {
            bL var2;
            bE var3;
            String var6;
            if ((var3 = (var2 = (bL)var4.next()).a()) != bU.d && var3 != bU.k && var3 != bU.f && var3 != bU.e) {
               if (var3 == bU.g) {
                  var6 = var2.a();
                  this.put(var6, ac.a((Object)null));
               }
            } else {
               var6 = var2.a();
               bP var5 = var2.a();
               this.put(var6, ac.a(this.a(var5)));
            }
         }

         return;
      }
   }

   public final Z a(String var1) {
      return (Z)this.get(var1);
   }

   private Object a(bP var1) {
      // $FF: Couldn't be decompiled
   }

   private Object[] a(bP var1) {
      int var2 = (Integer)var1.a(cd.g);
      var1 = (bP)var1.a(cd.f);
      Z[] var3 = new Z[var2];

      for(int var4 = 0; var4 < var2; ++var4) {
         var3[var4] = ac.a(this.a(var1));
      }

      return var3;
   }

   private static ad a(bP var0) {
      return ac.a((bK)var0.a(cd.h));
   }
}
