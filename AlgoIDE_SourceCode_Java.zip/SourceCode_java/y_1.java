import javax.swing.text.AttributeSet;
import javax.swing.text.DocumentFilter;
import javax.swing.text.DocumentFilter.FilterBypass;

public final class y extends DocumentFilter {
   // $FF: synthetic field
   private t a;

   public y(t var1) {
      this.a = var1;
      super();
   }

   public final void insertString(FilterBypass var1, int var2, String var3, AttributeSet var4) {
      if (var2 >= t.a(this.a)) {
         super.insertString(var1, var2, var3, var4);
      }

   }

   public final void remove(FilterBypass var1, int var2, int var3) {
      if (var2 >= t.a(this.a)) {
         super.remove(var1, var2, var3);
      }

   }

   public final void replace(FilterBypass var1, int var2, int var3, String var4, AttributeSet var5) {
      if (var2 >= t.a(this.a)) {
         super.replace(var1, var2, var3, var4, var5);
      }

   }
}
