public enum cc implements bO {
   a,
   b,
   c,
   d,
   e,
   f;

   public final String toString() {
      return super.toString().toLowerCase();
   }
}
