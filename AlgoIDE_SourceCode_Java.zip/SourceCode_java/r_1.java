import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

final class r extends AbstractAction {
   // $FF: synthetic field
   private d a;

   r(d var1) {
      this.a = var1;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      d.a(this.a);
   }
}
