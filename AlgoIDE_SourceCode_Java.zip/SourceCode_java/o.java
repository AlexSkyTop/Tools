import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

final class o extends AbstractAction {
   // $FF: synthetic field
   private d a;

   o(d var1) {
      this.a = var1;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      String var4;
      if ((var4 = (String)d.a(this.a).getSelectedValue()) != null) {
         M var2;
         (var2 = d.a(this.a)).a.remove(var4);
         var2.a.removeElement(var4);
         String var5 = d.a(this.a).a();
         if (var4.equals(var5)) {
            d.a(this.a).a("");
         }

      } else {
         JOptionPane.showMessageDialog(this.a, "No item selected!");
      }
   }
}
