public interface ch {
   void a(cf var1);
}
