public final class bC extends aK {
   public bC(aE var1) {
      super(var1);
   }

   public final void a() {
      StringBuilder var1 = new StringBuilder();
      StringBuilder var2 = new StringBuilder();
      char var3 = this.a();
      char var4 = this.b();
      var1.append(var3);

      do {
         if (Character.isWhitespace(var4)) {
            var4 = ' ';
         }

         if (var4 != var3 && var4 != 0) {
            var1.append(var4);
            var2.append(var4);
            var4 = this.b();
         }

         if (var4 == '\'') {
            while(var4 == '\'' && this.c() == '\'') {
               var1.append("''");
               var2.append(var4);
               this.b();
               var4 = this.b();
            }
         }
      } while(var4 != var3 && var4 != 0);

      if (var4 == var3) {
         this.b();
         var1.append(var3);
         super.a = aL.ay;
         super.a = a(var2.toString());
      } else {
         super.a = aL.az;
         super.a = aM.J;
      }

      super.a = a(var1.toString());
   }

   private static String a(String var0) {
      return var0.replaceAll("(?<!\\\\)\\\\n", "\n").replaceAll("(?<!\\\\)\\\\t", "\t").replaceAll("\\\\\\\\", "\\\\");
   }
}
