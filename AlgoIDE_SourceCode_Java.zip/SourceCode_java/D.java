import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import javax.swing.InputMap;
import javax.swing.JTextPane;
import javax.swing.KeyStroke;

public final class D {
   private N a;
   private static final HashMap a;

   public D(N var1, boolean var2) {
      this.a = var1;
      this.a(var2);
   }

   public final void a(boolean var1) {
      InputMap var2 = this.a.getInputMap();
      if (!var1) {
         var2.clear();
      } else {
         Iterator var5 = a.entrySet().iterator();

         while(var5.hasNext()) {
            Entry var3;
            KeyStroke var4 = KeyStroke.getKeyStroke((Character)(var3 = (Entry)var5.next()).getKey());
            var2.put(var4, var3.getValue());
            this.a.getActionMap().put(var3.getValue(), new E(this, var3));
         }

      }
   }

   // $FF: synthetic method
   static JTextPane a(D var0) {
      return var0.a;
   }

   static {
      (a = new HashMap()).put('(', ')');
      a.put('[', ']');
      a.put('{', '}');
      a.put('\'', '\'');
      a.put('"', '"');
   }
}
