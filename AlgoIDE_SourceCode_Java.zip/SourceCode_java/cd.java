public enum cd {
   a,
   b,
   c,
   d,
   e,
   f,
   g,
   h;
}
