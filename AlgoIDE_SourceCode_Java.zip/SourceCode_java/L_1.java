import java.awt.Component;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public final class L extends JLabel implements ListCellRenderer {
   public L() {
      this.setOpaque(true);
   }

   // $FF: synthetic method
   public final Component getListCellRendererComponent(JList var1, Object var2, int var3, boolean var4, boolean var5) {
      String var6 = (String)var2;
      if (var4) {
         this.setBackground(var1.getSelectionBackground());
         this.setForeground(var1.getSelectionForeground());
      } else {
         this.setBackground(var1.getBackground());
         this.setForeground(var1.getForeground());
      }

      URL var7;
      if ((var7 = this.getClass().getResource("/icons/16/file.png")) != null) {
         ImageIcon var8 = new ImageIcon(var7);
         this.setIcon(var8);
         this.setText(var6);
         this.setFont(var1.getFont());
      }

      return this;
   }
}
