// $FF: synthetic class
final class b {
   // $FF: synthetic field
   static final int[] a = new int[ci.values$4ae30073().length];

   static {
      try {
         a[ci.f - 1] = 1;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[ci.g - 1] = 2;
      } catch (NoSuchFieldError var0) {
      }
   }
}
