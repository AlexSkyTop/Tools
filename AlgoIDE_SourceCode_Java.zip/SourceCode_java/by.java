import java.util.EnumSet;

public final class by extends bq {
   private static final EnumSet a;

   public by(bq var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      var1 = super.a.a();
      bH var2 = bG.a(bT.c);
      bH var3 = bG.a(bT.d);
      bH var4 = bG.a(bT.s);
      var2.a(var3);
      var3.a(var4);
      var3 = (new bg(this)).a(var1);
      var4.a(var3);
      aH var10000;
      if (!cb.c(var3.a())) {
         var10000 = super.a;
         aH.a(var1, aM.d);
      }

      if ((var1 = this.a(a)).a == aL.g) {
         var1 = super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var1, aM.s);
      }

      (new bq(this)).a(var1, var2, aL.x);
      if ((var1 = super.a.a).a == aL.x) {
         super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var1, aM.M);
      }

      return var2;
   }

   static {
      (a = bq.b.clone()).add(aL.g);
      a.addAll(bq.c);
   }
}
