public final class cb {
   public static boolean a(bP var0) {
      return var0 != null && var0.a() == bV.b;
   }

   public static boolean a(bP var0, bP var1) {
      return a(var0) && a(var1);
   }

   private static boolean l(bP var0, bP var1) {
      return f(var0) && f(var1);
   }

   public static boolean b(bP var0, bP var1) {
      return e(var0) && e(var1);
   }

   private static boolean f(bP var0) {
      return var0 != null && var0.a() == bV.c;
   }

   public static boolean b(bP var0) {
      return a(var0) || f(var0);
   }

   public static boolean c(bP var0, bP var1) {
      return l(var0, var1) || m(var0, var1);
   }

   public static boolean c(bP var0) {
      return var0 != null && var0.a() == bV.d;
   }

   public static boolean d(bP var0, bP var1) {
      return c(var0) && c(var1);
   }

   public static boolean d(bP var0) {
      return var0 != null && var0.a() == bV.e;
   }

   public static boolean e(bP var0) {
      return var0 != null && var0.a().a();
   }

   public static boolean e(bP var0, bP var1) {
      return e(var0) && d(var1) || d(var0) && e(var1);
   }

   public static boolean f(bP var0, bP var1) {
      return e(var0) && a(var1) || a(var0) && e(var1);
   }

   public static boolean g(bP var0, bP var1) {
      return d(var0) && a(var1) || a(var0) && d(var1);
   }

   private static boolean m(bP var0, bP var1) {
      return f(var0) && a(var1) || a(var0) && f(var1);
   }

   private static boolean n(bP var0, bP var1) {
      return d(var0) && e(var1) || e(var0) && d(var1);
   }

   public static boolean h(bP var0, bP var1) {
      return e(var0) && f(var1) || f(var0) && e(var1);
   }

   public static boolean i(bP var0, bP var1) {
      return d(var0) && d(var1);
   }

   public static boolean j(bP var0, bP var1) {
      if (var0 != null && var1 != null) {
         var0 = var0.a();
         var1 = var1.a();
         boolean var2 = false;
         if (var0 == var1) {
            var2 = true;
         } else if (e(var0) && d(var1)) {
            var2 = true;
         } else if (f(var0) && a(var1)) {
            var2 = true;
         } else if (a(var0) && f(var1)) {
            var2 = true;
         } else if (var0.a() && var1.a()) {
            var2 = true;
         } else if (var0.a() == cc.d && var1.a() == cc.f) {
            var2 = true;
         } else if (var0.a() == cc.d && var1.a() == cc.d) {
            (Integer)var1.a(cd.g);
            (Integer)var0.a(cd.g);
            var0 = ((bP)var0.a(cd.f)).a();
            var1 = ((bP)var1.a(cd.f)).a();
            var2 = j(var0, var1);
         } else if (a(var0) && d(var1)) {
            var2 = true;
         } else if (d(var0) && a(var1)) {
            var2 = true;
         }

         return var2;
      } else {
         return false;
      }
   }

   public static boolean k(bP var0, bP var1) {
      if (var0 != null && var1 != null) {
         var0 = var0.a();
         var1 = var1.a();
         bO var2 = var0.a();
         if (var0 != var1 || var2 != cc.a && var2 != cc.b) {
            if (m(var0, var1)) {
               return true;
            } else if (g(var0, var1)) {
               return true;
            } else if (n(var0, var1)) {
               return true;
            } else {
               return var0.a() && var1.a();
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }
}
