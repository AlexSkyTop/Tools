public final class ck extends RuntimeException {
   public final String a;

   public ck(String var1) {
      this.a = var1;
   }
}
