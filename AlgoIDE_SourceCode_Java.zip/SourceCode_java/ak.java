public class ak extends at {
   public ak(ab var1) {
      super(var1);
   }

   public Object a(bH var1) {
      Object var2 = (bJ)((bL)var1.a(bR.b)).a(bZ.b) == bW.a ? new aj(this) : new al(this);
      ++a;
      return ((at)var2).a(var1);
   }
}
