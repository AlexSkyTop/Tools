import java.awt.Rectangle;
import javax.swing.text.BadLocationException;

final class U implements Runnable {
   // $FF: synthetic field
   private T a;

   U(T var1) {
      this.a = var1;
      super();
   }

   public final void run() {
      try {
         int var1 = T.a(this.a).getDocument().getLength();
         Rectangle var3;
         if ((var3 = T.a(this.a).modelToView(var1)) != null && var3.y != T.a(this.a)) {
            T.a(this.a);
            this.a.getParent().repaint();
            T.a(this.a, var3.y);
         }

      } catch (BadLocationException var2) {
      }
   }
}
