public final class aS extends aT {
   public aS(aT var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      bH var2 = bG.a(bT.e);
      String var4 = var1.a;
      if (!super.a.a.get()) {
         var4 = var4.toLowerCase();
      }

      bL var3 = super.a.c(var4);
      var2.a(bR.b, var3);
      var2.a(var3.a());
      var1 = super.a.a();
      bH var5 = this.a(var1, var3, true, false, false);
      var2.a(var5);
      return var2;
   }
}
