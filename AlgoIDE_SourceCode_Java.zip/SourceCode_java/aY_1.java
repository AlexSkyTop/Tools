public final class aY extends bq {
   public aY(bq var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      var1 = super.a.a();
      bH var2 = bG.a(bT.a);
      (new bq(this)).a(var1, var2, aL.i);
      if ((var1 = super.a.a).a == aL.i) {
         super.a.a();
      } else {
         aH var10000 = super.a;
         aH.a(var1, aM.u);
      }

      return var2;
   }
}
