public interface bM {
   void a(bL var1);

   bL a();

   bK a();

   bK b();

   bL a(String var1);

   bL b(String var1);

   bL c(String var1);

   String a();

   void a(String var1);

   Boolean a();

   void a(Boolean var1);
}
