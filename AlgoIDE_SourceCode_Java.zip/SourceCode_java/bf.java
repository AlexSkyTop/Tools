import java.util.ArrayList;
import java.util.EnumSet;

public final class bf extends bu {
   private static final EnumSet a;
   private static final EnumSet c;

   protected bf(bo var1) {
      super(var1);
   }

   public final bP a(aF var1) {
      bP var2 = bN.a(cc.b);
      int var3 = -1;
      ArrayList var4 = new ArrayList();
      super.a.a();

      aH var10000;
      do {
         var1 = this.a(a);
         ++var3;
         if (var1.a == aL.av) {
            String var9 = var1.a;
            if (!super.a.a.get()) {
               var9 = var9.toLowerCase();
            }

            if (super.a.b(var9) != null) {
               var10000 = super.a;
               aH.a(var1, aM.b);
            } else {
               bL var10;
               (var10 = super.a.a(var9)).a(bU.b);
               var10.a(var2);
               var10.a(bZ.a, var3);
               var10.a(var1.a);
               var4.add(var10);
            }

            super.a.a();
         } else {
            var10000 = super.a;
            aH.a(var1, aM.x);
         }

         aG var5;
         if ((var5 = (var1 = super.a.a).a) == aL.T) {
            var1 = super.a.a();
            if (c.contains(var1.a)) {
               var10000 = super.a;
               aH.a(var1, aM.x);
            }
         } else if (a.contains(var5)) {
            var10000 = super.a;
            aH.a(var1, aM.r);
         }
      } while(!c.contains(var1.a));

      if (var1.a == aL.aj) {
         super.a.a();
      } else {
         var10000 = super.a;
         aH.a(var1, aM.B);
      }

      var2.a(cd.a, var4);
      return var2;
   }

   static {
      a = EnumSet.of(aL.av, aL.T);
      (c = EnumSet.of(aL.aj, aL.U)).addAll(bc.d);
   }
}
