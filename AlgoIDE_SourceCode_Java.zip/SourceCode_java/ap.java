// $FF: synthetic class
final class ap {
   // $FF: synthetic field
   static final int[] a = new int[bT.values().length];

   static {
      try {
         a[bT.E.ordinal()] = 1;
      } catch (NoSuchFieldError var23) {
      }

      try {
         a[bT.D.ordinal()] = 2;
      } catch (NoSuchFieldError var22) {
      }

      try {
         a[bT.H.ordinal()] = 3;
      } catch (NoSuchFieldError var21) {
      }

      try {
         a[bT.I.ordinal()] = 4;
      } catch (NoSuchFieldError var20) {
      }

      try {
         a[bT.J.ordinal()] = 5;
      } catch (NoSuchFieldError var19) {
      }

      try {
         a[bT.K.ordinal()] = 6;
      } catch (NoSuchFieldError var18) {
      }

      try {
         a[bT.w.ordinal()] = 7;
      } catch (NoSuchFieldError var17) {
      }

      try {
         a[bT.s.ordinal()] = 8;
      } catch (NoSuchFieldError var16) {
      }

      try {
         a[bT.e.ordinal()] = 9;
      } catch (NoSuchFieldError var15) {
      }

      try {
         a[bT.m.ordinal()] = 10;
      } catch (NoSuchFieldError var14) {
      }

      try {
         a[bT.n.ordinal()] = 11;
      } catch (NoSuchFieldError var13) {
      }

      try {
         a[bT.B.ordinal()] = 12;
      } catch (NoSuchFieldError var12) {
      }

      try {
         a[bT.v.ordinal()] = 13;
      } catch (NoSuchFieldError var11) {
      }

      try {
         a[bT.o.ordinal()] = 14;
      } catch (NoSuchFieldError var10) {
      }

      try {
         a[bT.p.ordinal()] = 15;
      } catch (NoSuchFieldError var9) {
      }

      try {
         a[bT.q.ordinal()] = 16;
      } catch (NoSuchFieldError var8) {
      }

      try {
         a[bT.r.ordinal()] = 17;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a[bT.t.ordinal()] = 18;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a[bT.u.ordinal()] = 19;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a[bT.x.ordinal()] = 20;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a[bT.z.ordinal()] = 21;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a[bT.y.ordinal()] = 22;
      } catch (NoSuchFieldError var2) {
      }

      try {
         a[bT.A.ordinal()] = 23;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[bT.C.ordinal()] = 24;
      } catch (NoSuchFieldError var0) {
      }
   }
}
