public final class ci extends Enum {
   public static final int a = 1;
   private static int h = 2;
   private static int i = 3;
   private static int j = 4;
   private static int k = 5;
   private static int l = 6;
   private static int m = 7;
   public static final int b = 8;
   public static final int c = 9;
   private static int n = 10;
   private static int o = 11;
   public static final int d = 12;
   public static final int e = 13;
   public static final int f = 14;
   public static final int g = 15;
   // $FF: synthetic field
   private static final int[] a;

   public static int[] values$4ae30073() {
      return (int[])a.clone();
   }

   static {
      a = new int[]{a, h, i, j, k, l, m, b, c, n, o, d, e, f, g};
   }
}
