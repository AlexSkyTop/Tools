import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.SwingUtilities;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.JTextComponent;
import javax.swing.text.Highlighter.HighlightPainter;

public final class S implements MouseListener, MouseMotionListener, CaretListener, HighlightPainter {
   public final N a;
   private Color a;
   public Rectangle a;
   public boolean a;

   public S(N var1, boolean var2) {
      this(var1, var2, (byte)0);
      Color var5 = var1.getSelectionColor();
      int var3 = Math.min(255, (int)((double)var5.getRed() * 1.2D));
      int var4 = Math.min(255, (int)((double)var5.getGreen() * 1.2D));
      int var6 = Math.min(255, (int)((double)var5.getBlue() * 1.2D));
      this.a = new Color(var3, var4, var6);
   }

   private S(N var1, boolean var2, byte var3) {
      this.a = var1;
      this.a = var2;
      this.a = null;
      var1.addCaretListener(this);
      var1.addMouseListener(this);
      var1.addMouseMotionListener(this);

      try {
         var1.getHighlighter().addHighlight(0, 0, this);
      } catch (BadLocationException var4) {
      }
   }

   public final void paint(Graphics var1, int var2, int var3, Shape var4, JTextComponent var5) {
      if (this.a) {
         try {
            Rectangle var7 = var5.modelToView(var5.getCaretPosition());
            var1.setColor(this.a);
            var1.fillRect(0, var7.y, var5.getWidth(), var7.height);
            if (this.a == null) {
               this.a = var7;
            }

            return;
         } catch (BadLocationException var6) {
            System.out.println(var6);
         }
      }

   }

   private void a() {
      SwingUtilities.invokeLater(() -> {
         try {
            int var1 = this.a.getCaretPosition();
            Rectangle var3 = this.a.modelToView(var1);
            if (this.a != null && this.a.y != var3.y) {
               this.a.repaint(0, this.a.y, this.a.getWidth(), this.a.height);
               this.a = var3;
            }

         } catch (BadLocationException var2) {
         }
      });
   }

   public final void caretUpdate(CaretEvent var1) {
      this.a();
   }

   public final void mousePressed(MouseEvent var1) {
      this.a();
   }

   public final void mouseClicked(MouseEvent var1) {
   }

   public final void mouseEntered(MouseEvent var1) {
   }

   public final void mouseExited(MouseEvent var1) {
   }

   public final void mouseReleased(MouseEvent var1) {
   }

   public final void mouseDragged(MouseEvent var1) {
      this.a();
   }

   public final void mouseMoved(MouseEvent var1) {
   }
}
