import java.io.Serializable;

public class aF {
   public aG a;
   public String a;
   public Serializable a;
   private aE a;
   public int a;
   public int b;
   public String b;

   public aF(aE var1) {
      this.a = var1;
      this.a = var1.a;
      this.b = var1.b;
      this.b = var1.a;
      this.a();
   }

   protected void a() {
      this.a = Character.toString(this.a.a());
      this.a = null;
      this.a.b();
   }

   protected final char a() {
      return this.a.a();
   }

   protected final char b() {
      return this.a.b();
   }

   protected final char c() {
      return this.a.c();
   }
}
