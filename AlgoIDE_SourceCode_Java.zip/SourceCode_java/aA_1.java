import java.util.ArrayList;

public final class aA extends ArrayList implements ah {
   private final az a = new az();

   public final Y a(int var1) {
      return this.a.a(var1);
   }

   private int a() {
      int var1;
      return (var1 = this.size() - 1) >= 0 ? ((Y)this.get(var1)).a() : -1;
   }

   public final void a(av var1) {
      int var2 = var1.a();
      this.add(var1);
      this.a.a(var2, var1);
   }

   public final void a() {
      this.a.a(this.a());
      this.remove(this.size() - 1);
   }

   public final boolean a() {
      int var1 = this.a();
      return this.a(var1).a();
   }

   public final void b() {
      int var1 = this.a();
      this.a(var1).a();
   }
}
