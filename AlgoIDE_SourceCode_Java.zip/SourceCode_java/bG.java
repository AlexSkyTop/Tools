public final class bG {
   public static bH a(bI var0) {
      return new bS(var0);
   }
}
