// $FF: synthetic class
final class bp {
   // $FF: synthetic field
   static final int[] a = new int[aL.values().length];

   static {
      try {
         a[aL.av.ordinal()] = 1;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a[aL.ai.ordinal()] = 2;
      } catch (NoSuchFieldError var2) {
      }

      try {
         a[aL.T.ordinal()] = 3;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[aL.U.ordinal()] = 4;
      } catch (NoSuchFieldError var0) {
      }
   }
}
