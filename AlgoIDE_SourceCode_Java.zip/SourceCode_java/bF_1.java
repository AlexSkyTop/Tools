public interface bF {
   bH a(bH var1);

   bH a();
}
