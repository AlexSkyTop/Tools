public final class Q {
   public final N a;

   public Q(N var1) {
      this.a = var1;
      var1.getActionMap().put("insert-break", new R());
   }
}
