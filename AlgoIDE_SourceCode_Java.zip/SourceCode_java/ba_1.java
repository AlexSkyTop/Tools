import java.util.EnumSet;

public final class ba extends bc {
   private static final EnumSet f;
   static final EnumSet a;
   private static final EnumSet g;
   private static final EnumSet h;

   public ba(aI var1) {
      super(var1);
   }

   public final bL a(aF var1, bL var2) {
      for(var1 = this.a(f); var1.a == aL.av; var1 = this.a(f)) {
         String var4 = var1.a;
         if (!super.a.a.get()) {
            var4 = var4.toLowerCase();
         }

         aH var10000;
         bL var3;
         if (super.a.b(var4) == null) {
            (var3 = super.a.a(var4)).a(var1.a);
         } else {
            var10000 = super.a;
            aH.a(var1, aM.b);
            var3 = null;
         }

         super.a.a();
         if ((var1 = this.a(g)).a == aL.Z) {
            var1 = super.a.a();
         } else {
            var10000 = super.a;
            aH.a(var1, aM.w);
         }

         Object var5 = this.a();
         if (var3 != null) {
            var3.a(bU.a);
            var3.a(bZ.a, var5);
            bP var6 = var1.a == aL.av ? this.a(var1) : a(var5);
            var3.a(var6);
         }

         if ((var1 = super.a.a).a == aL.U) {
            while(var1.a == aL.U) {
               var1 = super.a.a();
            }
         }
      }

      return null;
   }

   protected final Object a() {
      // $FF: Couldn't be decompiled
   }

   private Object a(aF var1, aG var2) {
      String var3 = var1.a;
      if (!super.a.a.get()) {
         var3 = var3.toLowerCase();
      }

      bL var5 = super.a.c(var3);
      super.a.a();
      aH var10000;
      if (var5 == null) {
         var10000 = super.a;
         aH.a(var1, aM.c);
         return null;
      } else {
         bE var4;
         Object var6;
         if ((var4 = var5.a()) == bU.a) {
            var6 = var5.a(bZ.a);
            var5.a(var1.a);
            if (var6 instanceof Integer) {
               return var2 == aL.L ? -(Integer)var6 : var6;
            } else if (var6 instanceof Float) {
               return var2 == aL.L ? -(Float)var6 : var6;
            } else if (var6 instanceof String) {
               if (var2 != null) {
                  var10000 = super.a;
                  aH.a(var1, aM.f);
               }

               return var6;
            } else {
               return null;
            }
         } else if (var4 == bU.b) {
            var6 = var5.a(bZ.a);
            var5.a(var1.a);
            if (var2 != null) {
               var10000 = super.a;
               aH.a(var1, aM.f);
            }

            return var6;
         } else if (var4 == null) {
            var10000 = super.a;
            aH.a(var1, aM.E);
            return null;
         } else {
            var10000 = super.a;
            aH.a(var1, aM.f);
            return null;
         }
      }
   }

   protected static bP a(Object var0) {
      bP var1 = null;
      if (var0 instanceof Integer) {
         var1 = bV.b;
      } else if (var0 instanceof Float) {
         var1 = bV.c;
      } else if (var0 instanceof String) {
         if (((String)var0).length() == 1) {
            var1 = bV.e;
         } else {
            var1 = bN.a((String)var0);
         }
      }

      return var1;
   }

   protected final bP a(aF var1) {
      String var3 = var1.a;
      if (!super.a.a.get()) {
         var3 = var3.toLowerCase();
      }

      bL var4;
      if ((var4 = super.a.c(var3)) == null) {
         return null;
      } else {
         bE var2;
         return (var2 = var4.a()) != bU.a && var2 != bU.b ? null : var4.a();
      }
   }

   static {
      (f = bc.c.clone()).add(aL.av);
      (g = (a = EnumSet.of(aL.av, aL.aw, aL.ax, aL.K, aL.L, aL.ay, aL.U)).clone()).add(aL.Z);
      g.add(aL.U);
      (h = bc.c.clone()).add(aL.U);
      h.add(aL.av);
   }
}
