// $FF: synthetic class
final class ay {
   // $FF: synthetic field
   static final int[] a = new int[cc.values().length];

   static {
      try {
         a[cc.d.ordinal()] = 1;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[cc.e.ordinal()] = 2;
      } catch (NoSuchFieldError var0) {
      }
   }
}
