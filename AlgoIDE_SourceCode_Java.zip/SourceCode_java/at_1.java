import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class at extends ab {
   public at(ab var1) {
      super(var1);
   }

   public Object a(bH var1) {
      // $FF: Couldn't be decompiled
   }

   protected static Object a(bP var0, Object var1) {
      if (!(var1 instanceof String)) {
         return var1;
      } else {
         String var2 = (String)var1;
         if (var0 == bV.e) {
            return var2.charAt(0);
         } else if (!var0.a()) {
            return var1;
         } else {
            Z[] var3 = new Z[var2.length()];

            for(int var4 = 0; var4 < var2.length(); ++var4) {
               var3[var4] = ac.a((Object)var2.charAt(var4));
            }

            return var3;
         }
      }
   }

   protected final Object a(Object var1, bH var2) {
      bH var3;
      at var9;
      ag var10000;
      if (var1 instanceof HashMap) {
         HashMap var10001 = (HashMap)var1;
         var3 = var2;
         HashMap var10 = var10001;
         var9 = this;
         HashMap var4 = new HashMap();
         if (var10 != null) {
            Iterator var6 = var10.entrySet().iterator();

            while(var6.hasNext()) {
               Entry var7;
               String var8 = (String)(var7 = (Entry)var6.next()).getKey();
               Z var11 = (Z)var7.getValue();
               Object var12 = var9.a(var11.a(), var3);
               var4.put(var8, ac.a(var12));
            }
         } else {
            var10000 = super.a;
            ag.a(var2, af.a);
         }

         var1 = var4;
      } else if (var1 instanceof Z[]) {
         Z[] var18 = (Z[])var1;
         var3 = var2;
         Z[] var13 = var18;
         var9 = this;
         Z[] var5;
         if (var13 != null) {
            int var14;
            var5 = new Z[var14 = var13.length];

            for(int var15 = 0; var15 < var14; ++var15) {
               Z var16 = var13[var15];
               Object var17 = var9.a(var16.a(), var3);
               var5[var15] = ac.a(var17);
            }
         } else {
            if (!super.a.b.get()) {
               var10000 = super.a;
               ag.a(var2, af.a);
            }

            var5 = new Z[1];
         }

         var1 = var5;
      }

      return var1;
   }

   protected final Object a(bH var1, bP var2, Object var3) {
      if (var2.a() == cc.c) {
         int var4 = (Integer)var2.a(cd.c);
         int var5 = (Integer)var2.a(cd.d);
         ag var10000;
         if ((Integer)var3 < var4) {
            var10000 = super.a;
            ag.a(var1, af.b);
            return var4;
         } else if ((Integer)var3 > var5) {
            var10000 = super.a;
            ag.a(var1, af.b);
            return var5;
         } else {
            return var3;
         }
      } else {
         return var3;
      }
   }

   private static Object b(bH var0) {
      Object var1;
      for(var1 = null; var0 != null && (var1 = var0.a(bR.a)) == null; var0 = var0.a()) {
      }

      return var1;
   }

   protected final void a(bH var1, String var2, Object var3) {
      Object var4;
      if (super.a.d.get() && (var4 = b(var1)) != null) {
         this.a(new cf(ci.b, new Object[]{var4, var2, var3}));
      }

   }

   protected final void b(bH var1, String var2, Object var3) {
      Object var4;
      if (super.a.d.get() && (var4 = b(var1)) != null) {
         this.a(new cf(ci.c, new Object[]{var4, var2, var3}));
      }

   }

   protected final void a(bH var1, String var2) {
      Object var3;
      if (super.a.d.get() && (var3 = b(var1)) != null) {
         this.a(new cf(ci.d, new Object[]{var3, var2}));
      }

   }

   protected final void b(bH var1, String var2) {
      Object var3;
      if (super.a.d.get() && (var3 = b(var1)) != null) {
         this.a(new cf(ci.e, new Object[]{var3, var2}));
      }

   }
}
