import java.io.OutputStream;

final class x extends OutputStream {
   private final s a;
   private final z a;

   private x(s var1, z var2) {
      this.a = var1;
      this.a = var2;
   }

   public final void write(byte[] var1, int var2, int var3) {
      try {
         this.a.a(var1, var2, var3);
         this.a.onUpdate();
      } catch (InterruptedException var4) {
         var4.printStackTrace();
      }
   }

   public final void write(int var1) {
      this.write(new byte[]{(byte)var1}, 0, 1);
   }

   // $FF: synthetic method
   x(s var1, z var2, byte var3) {
      this(var1, var2);
   }
}
