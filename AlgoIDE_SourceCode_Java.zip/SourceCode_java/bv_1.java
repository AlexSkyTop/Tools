// $FF: synthetic class
final class bv {
   // $FF: synthetic field
   static final int[] a = new int[aL.values().length];

   static {
      try {
         a[aL.b.ordinal()] = 1;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[aL.s.ordinal()] = 2;
      } catch (NoSuchFieldError var0) {
      }
   }
}
