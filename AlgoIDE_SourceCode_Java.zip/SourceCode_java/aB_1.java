public final class aB extends aF {
   public aB(aE var1) {
      super(var1);
      super.a = aL.aA;
   }
}
