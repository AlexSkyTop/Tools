import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.text.BadLocationException;

final class u extends AbstractAction {
   // $FF: synthetic field
   private Action a;
   // $FF: synthetic field
   private t a;

   u(t var1, Action var2) {
      this.a = var1;
      this.a = var2;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      int var2 = this.a.getCaretPosition() - t.a(this.a);

      try {
         String var3 = this.a.getText(t.a(this.a), var2).trim();
         System.out.println("[" + var3 + "]");
         t.a(this.a, t.a(this.a) + var2);

         for(var2 = 0; var2 < var3.length(); ++var2) {
            t.a(this.a).a(var3.charAt(var2));
         }

         t.a(this.a).a(10);
         t.a(this.a).a(-1);
         t.b(this.a, this.a.getText().length());
      } catch (BadLocationException var4) {
      }

      this.a.actionPerformed(var1);
   }
}
