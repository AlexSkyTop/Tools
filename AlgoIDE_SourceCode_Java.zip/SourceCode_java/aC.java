public abstract class aC {
   public final bM a;
   public final aD a;
   public final V a;

   public aC(aJ var1, ca var2, V var3) {
      this.a = var1;
      this.a = var2;
      this.a = var3;
   }

   public aC(aI var1) {
      this.a = var1.a;
      this.a = var1.a;
      this.a = var1.a;
   }

   public abstract void a();
}
