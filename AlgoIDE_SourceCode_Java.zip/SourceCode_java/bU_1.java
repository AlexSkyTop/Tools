public enum bU implements bE {
   a,
   b("enumeration constant"),
   c,
   d,
   e("record field"),
   f("value parameter"),
   g("VAR parameter"),
   h("program parameter"),
   i,
   j,
   k,
   l;

   private final String a;

   private bU() {
      this.a = this.toString().toLowerCase();
   }

   private bU(String var3) {
      this.a = var3;
   }
}
