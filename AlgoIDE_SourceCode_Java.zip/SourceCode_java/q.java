import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

final class q extends AbstractAction {
   // $FF: synthetic field
   private a a;
   // $FF: synthetic field
   private d a;

   q(d var1, a var2) {
      this.a = var1;
      this.a = var2;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      String var2 = d.a(this.a).getText();
      this.a.a(var2);
   }
}
