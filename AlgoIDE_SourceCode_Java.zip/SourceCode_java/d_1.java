import java.awt.BorderLayout;
import java.awt.Component;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.prefs.PreferenceChangeListener;
import javax.swing.ActionMap;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.border.Border;

public final class d extends JFrame {
   private final N a;
   private final JList a;
   private final M a;
   private final JButton a;
   private final JButton b;
   private final t a;
   private final B a = B.a();
   private final V a;

   public d() {
      this.a = new N(new P(), this.a.b());
      JScrollPane var1 = new JScrollPane(this.a);
      T var2;
      (var2 = new T(this.a)).a = true;
      var1.setRowHeaderView(var2);
      S var12 = new S(this.a, this.a.e());
      Q var3 = new Q(this.a);
      D var4 = new D(this.a, this.a.d());
      F var5 = new F(this.a, cl.a, this.a.f());
      this.a = new t(this.a.b());
      this.a = new V(this.a.a(), this.a.a(), this.a.b(), this.a.g());
      B var10000 = this.a;
      PreferenceChangeListener var19 = (var5x) -> {
         String var11 = var5x.getKey();
         byte var6 = -1;
         switch(var11.hashCode()) {
         case -2073970999:
            if (var11.equals("AUTO_COMPLETE_KEY")) {
               var6 = 4;
            }
            break;
         case -1225180187:
            if (var11.equals("HIGHLIGHT_CURRENT_LINE_KEY")) {
               var6 = 2;
            }
            break;
         case -965804054:
            if (var11.equals("AUTO_PAIR_KEY")) {
               var6 = 3;
            }
            break;
         case -325620548:
            if (var11.equals("AUTO_INDENT_KEY")) {
               var6 = 1;
            }
            break;
         case 321959891:
            if (var11.equals("TEXT_SIZE_KEY")) {
               var6 = 0;
            }
            break;
         case 464352807:
            if (var11.equals("CASE_SENSITIVE_KEY")) {
               var6 = 6;
            }
            break;
         case 545203288:
            if (var11.equals("USE_DEFAULT_VALUES_KEY")) {
               var6 = 7;
            }
            break;
         case 990103084:
            if (var11.equals("WITH_NEW_LINE_KEY")) {
               var6 = 8;
            }
            break;
         case 2021448175:
            if (var11.equals("START_INDEX_ARRAY_KEY")) {
               var6 = 5;
            }
         }

         boolean var9;
         V var10000;
         switch(var6) {
         case 0:
            this.a.a(this.a.b());
            this.a.a(this.a.b());
            return;
         case 1:
            var9 = this.a.c();
            ActionMap var8 = var3.a.getActionMap();
            if (var9) {
               var8.put("insert-break", new R());
               return;
            }

            var8.remove("insert-break");
            return;
         case 2:
            S var12x = var12;
            var9 = this.a.e();
            S var7 = var12x;
            var12x.a = var9;
            if (var7.a != null) {
               var7.a.repaint(0, var7.a.y, var7.a.getWidth(), var7.a.height);
            } else {
               var7.a.repaint();
            }
         case 3:
            var4.a(this.a.d());
         case 4:
            var5.a(this.a.f());
            return;
         case 5:
            var10000 = this.a;
            int var10 = this.a.a();
            var10000.a.set(var10);
            return;
         case 6:
            var10000 = this.a;
            var9 = this.a.a();
            var10000.a.set(var9);
            return;
         case 7:
            var10000 = this.a;
            var9 = this.a.b();
            var10000.b.set(var9);
            return;
         case 8:
            var10000 = this.a;
            var9 = this.a.g();
            var10000.e.set(var9);
         default:
         }
      };
      var10000.a.addPreferenceChangeListener(var19);
      DefaultListModel var14 = new DefaultListModel();
      this.a = new JList(var14);
      this.a = new M(var14);
      this.b = new JButton();
      this.a = new JButton();
      this.setSize(600, 600);
      this.setDefaultCloseOperation(3);
      this.setTitle("AlgoIDE");
      this.setLocationRelativeTo((Component)null);
      URL var17;
      if ((var17 = this.getClass().getResource("/icons/96/algo.png")) != null) {
         this.setIconImage((new ImageIcon(var17)).getImage());
      }

      JSplitPane var9;
      (var9 = new JSplitPane(0, var1, new JScrollPane(this.a))).setDividerLocation(360);
      JScrollPane var22 = new JScrollPane(this.a);
      JSplitPane var6;
      (var6 = new JSplitPane(1, var22, var9)).setDividerLocation(150);
      var6.setOneTouchExpandable(true);
      var6.setBorder((Border)null);
      JPanel var20;
      (var20 = (JPanel)this.getContentPane()).setLayout(new BorderLayout());
      var20.add(var6, "Center");
      this.b.setToolTipText("New file");
      if ((var17 = this.getClass().getResource("/icons/24/add.png")) != null) {
         this.b.setIcon(new ImageIcon(var17));
      }

      this.b.addActionListener(new e(this));
      JPanel var31 = var20;
      JToolBar var21;
      (var21 = new JToolBar()).add(this.b);
      this.a.setEnabled(false);
      this.a.setToolTipText("Delete file");
      this.a.setIcon(cm.a("/icons/24/delete.png"));
      this.a.addActionListener(new o(this));
      var21.add(this.a);
      JButton var10;
      (var10 = new JButton()).setToolTipText("Save file");
      var10.setIcon(cm.a("/icons/24/save.png"));
      var10.addActionListener(new p(this));
      var21.add(var10);
      var21.addSeparator();
      JButton var24;
      (var24 = new JButton()).setToolTipText("Run code");
      var24.setIcon(cm.a("/icons/24/play.png"));
      a var27 = new a(this.a, this.a, this.a);
      var24.addActionListener(new q(this, var27));
      var21.add(var24);
      var31.add(var21, "First");
      JMenuBar var23 = new JMenuBar();
      JMenu var11 = new JMenu("File");
      JMenuItem var26;
      (var26 = new JMenuItem("New", 78)).setIcon(cm.a("/icons/16/new.png"));
      var11.add(var26);
      var26.addActionListener(new r(this));
      JMenuItem var28;
      (var28 = new JMenuItem("Open")).setIcon(cm.a("/icons/16/open.png"));
      var11.add(var28);
      var28.addActionListener(new f(this));
      (var26 = new JMenuItem("Save")).setIcon(cm.a("/icons/16/save.png"));
      var11.add(var26);
      var26.addActionListener(new g(this));
      var11.addSeparator();
      (var26 = new JMenuItem("Settings...")).setIcon(cm.a("/icons/16/setting.png"));
      var11.add(var26);
      var26.addActionListener(new h(this));
      var11.addSeparator();
      (var26 = new JMenuItem("Quit")).setIcon(cm.a("/icons/16/close.png"));
      var11.add(var26);
      var26.addActionListener(new i(this));
      JMenu var29 = new JMenu("Edit");
      (var28 = new JMenuItem("Copy", 67)).setIcon(cm.a("/icons/16/copy.png"));
      var29.add(var28);
      (var28 = new JMenuItem("Paste", 86)).setIcon(cm.a("/icons/16/paste.png"));
      var29.add(var28);
      (var28 = new JMenuItem("Cut", 88)).setIcon(cm.a("/icons/16/cut.png"));
      var29.add(var28);
      (var28 = new JMenuItem("Delete", 78)).setIcon(cm.a("/icons/16/delete.png"));
      var29.add(var28);
      var29.addSeparator();
      (var28 = new JMenuItem("Select All", 83)).setIcon(cm.a("/icons/16/select-all.png"));
      var29.add(var28);
      JMenu var30 = new JMenu("Help");
      JMenuItem var7 = new JMenuItem("Help", 83);
      var30.add(var7);
      (var7 = new JMenuItem("About", 83)).setIcon(cm.a("/icons/16/about.png"));
      var30.add(var7);
      var7.addActionListener(new j(this));
      var23.add(var11);
      var23.add(var29);
      var23.add(var30);
      this.setJMenuBar(var23);
      this.a.setSelectionMode(0);
      this.a.setLayoutOrientation(2);
      this.a.setVisibleRowCount(-1);
      this.a.setLayoutOrientation(0);
      this.a.setCellRenderer(new L());
      this.a.setFixedCellHeight(30);
      this.a.addMouseListener(new k(this));
      M var32 = this.a;
      K var25 = (var1x, var2x) -> {
         try {
            if (var1x.isEmpty()) {
               this.a.setText("");
            } else {
               this.a.setText(cm.a(var2x));
            }
         } catch (IOException var3) {
            JOptionPane.showMessageDialog(this, var3.getMessage());
            throw new RuntimeException(var3);
         }
      };
      var32.a.add(var25);
      String var13;
      if ((var13 = this.a.a()) != null) {
         this.a.setSelectedIndex(var14.indexOf(var13));
         this.a.setEnabled(true);

         try {
            this.a.setText(cm.a(this.a.a(var13)));
         } catch (IOException var8) {
            JOptionPane.showMessageDialog(this, var8.getMessage());
            throw new RuntimeException(var8);
         }
      }

      InputMap var15 = this.a.getInputMap();
      ActionMap var16 = this.a.getActionMap();
      KeyStroke var18 = KeyStroke.getKeyStroke(107, 2);
      var15.put(var18, "increaseTextSize");
      var16.put("increaseTextSize", new l(this));
      var18 = KeyStroke.getKeyStroke(109, 2);
      var15.put(var18, "decreaseTextSize");
      var16.put("decreaseTextSize", new m(this));
      var18 = KeyStroke.getKeyStroke(111, 2);
      var15.put(var18, "commentText");
      var16.put("commentText", new n(this));
   }

   // $FF: synthetic method
   static void a(d var0) {
      JFileChooser var1;
      if ((var1 = new JFileChooser()).showDialog(var0, "Add") == 0) {
         File var13 = var1.getSelectedFile();
         var0.a.a(var13.getName(), var13.getPath());

         try {
            BufferedWriter var2 = new BufferedWriter(new FileWriter(var13));
            Throwable var3 = null;
            boolean var8 = false;

            try {
               var8 = true;
               var2.write("Algorithme " + var13.getName() + "\nDébut\n\nFin");
               var2.flush();
               var8 = false;
            } catch (Throwable var10) {
               var3 = var10;
               throw var10;
            } finally {
               if (var8) {
                  if (var3 != null) {
                     try {
                        var2.close();
                     } catch (Throwable var9) {
                        var3.addSuppressed(var9);
                     }
                  } else {
                     var2.close();
                  }

               }
            }

            var2.close();
            return;
         } catch (Exception var12) {
            JOptionPane.showMessageDialog(var0, var12.getMessage());
         }
      }

   }

   // $FF: synthetic method
   static JList a(d var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static M a(d var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static JButton a(d var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static N a(d var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static t a(d var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static void a(d var0, String var1, String var2) {
      File var13 = new File(var1);

      try {
         BufferedWriter var14 = new BufferedWriter(new FileWriter(var13));
         Throwable var3 = null;
         boolean var8 = false;

         try {
            var8 = true;
            var14.write(var2);
            var14.flush();
            var8 = false;
         } catch (Throwable var10) {
            var3 = var10;
            throw var10;
         } finally {
            if (var8) {
               if (var3 != null) {
                  try {
                     var14.close();
                  } catch (Throwable var9) {
                     var3.addSuppressed(var9);
                  }
               } else {
                  var14.close();
               }

            }
         }

         var14.close();
      } catch (IOException var12) {
         JOptionPane.showMessageDialog(var0, var12.getMessage());
      }
   }

   // $FF: synthetic method
   static void b(d var0) {
      JFileChooser var1;
      if ((var1 = new JFileChooser()).showOpenDialog(var0) == 0) {
         File var2 = var1.getSelectedFile();
         var0.a.a(var2.getName(), var2.getPath());
      }

   }

   // $FF: synthetic method
   static void c(d var0) {
      JFileChooser var1;
      if ((var1 = new JFileChooser()).showSaveDialog(var0) == 0) {
         File var13 = var1.getSelectedFile();
         var0.a.a(var13.getName(), var13.getPath());

         try {
            BufferedWriter var14 = new BufferedWriter(new FileWriter(var13));
            Throwable var2 = null;
            boolean var8 = false;

            try {
               var8 = true;
               var14.write(var0.a.getText());
               var14.flush();
               var8 = false;
            } catch (Throwable var10) {
               var2 = var10;
               throw var10;
            } finally {
               if (var8) {
                  if (var2 != null) {
                     try {
                        var14.close();
                     } catch (Throwable var9) {
                        var2.addSuppressed(var9);
                     }
                  } else {
                     var14.close();
                  }

               }
            }

            var14.close();
            return;
         } catch (Exception var12) {
            JOptionPane.showMessageDialog(var0, var12.getMessage());
         }
      }

   }
}
