import java.util.ArrayList;

public final class aq extends at {
   public aq(at var1) {
      super(var1);
   }

   public final Object a(bH var1) {
      ArrayList var6;
      bH var2 = (bH)(var6 = var1.a()).get(0);
      bH var3 = (bH)var6.get(1);
      var1 = var6.size() > 2 ? (bH)var6.get(2) : null;
      ao var4 = new ao(this);
      at var5 = new at(this);
      if ((Boolean)var4.a(var2)) {
         var5.a(var3);
      } else if (var1 != null) {
         var5.a(var1);
      }

      ++a;
      return null;
   }
}
