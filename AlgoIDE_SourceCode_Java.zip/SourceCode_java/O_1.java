import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

final class O extends AbstractAction {
   // $FF: synthetic field
   private N a;

   O(N var1) {
      this.a = var1;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      this.a.a("    ", this.a.getCaretPosition());
   }
}
