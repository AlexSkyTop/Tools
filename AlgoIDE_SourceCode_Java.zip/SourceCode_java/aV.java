// $FF: synthetic class
final class aV {
   // $FF: synthetic field
   static final int[] a = new int[bW.values().length];

   static {
      try {
         a[bW.d.ordinal()] = 1;
      } catch (NoSuchFieldError var27) {
      }

      try {
         a[bW.e.ordinal()] = 2;
      } catch (NoSuchFieldError var26) {
      }

      try {
         a[bW.k.ordinal()] = 3;
      } catch (NoSuchFieldError var25) {
      }

      try {
         a[bW.l.ordinal()] = 4;
      } catch (NoSuchFieldError var24) {
      }

      try {
         a[bW.m.ordinal()] = 5;
      } catch (NoSuchFieldError var23) {
      }

      try {
         a[bW.t.ordinal()] = 6;
      } catch (NoSuchFieldError var22) {
      }

      try {
         a[bW.j.ordinal()] = 7;
      } catch (NoSuchFieldError var21) {
      }

      try {
         a[bW.o.ordinal()] = 8;
      } catch (NoSuchFieldError var20) {
      }

      try {
         a[bW.i.ordinal()] = 9;
      } catch (NoSuchFieldError var19) {
      }

      try {
         a[bW.z.ordinal()] = 10;
      } catch (NoSuchFieldError var18) {
      }

      try {
         a[bW.y.ordinal()] = 11;
      } catch (NoSuchFieldError var17) {
      }

      try {
         a[bW.C.ordinal()] = 12;
      } catch (NoSuchFieldError var16) {
      }

      try {
         a[bW.A.ordinal()] = 13;
      } catch (NoSuchFieldError var15) {
      }

      try {
         a[bW.B.ordinal()] = 14;
      } catch (NoSuchFieldError var14) {
      }

      try {
         a[bW.p.ordinal()] = 15;
      } catch (NoSuchFieldError var13) {
      }

      try {
         a[bW.f.ordinal()] = 16;
      } catch (NoSuchFieldError var12) {
      }

      try {
         a[bW.g.ordinal()] = 17;
      } catch (NoSuchFieldError var11) {
      }

      try {
         a[bW.h.ordinal()] = 18;
      } catch (NoSuchFieldError var10) {
      }

      try {
         a[bW.n.ordinal()] = 19;
      } catch (NoSuchFieldError var9) {
      }

      try {
         a[bW.q.ordinal()] = 20;
      } catch (NoSuchFieldError var8) {
      }

      try {
         a[bW.b.ordinal()] = 21;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a[bW.c.ordinal()] = 22;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a[bW.r.ordinal()] = 23;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a[bW.s.ordinal()] = 24;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a[bW.u.ordinal()] = 25;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a[bW.v.ordinal()] = 26;
      } catch (NoSuchFieldError var2) {
      }

      try {
         a[bW.w.ordinal()] = 27;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[bW.x.ordinal()] = 28;
      } catch (NoSuchFieldError var0) {
      }
   }
}
