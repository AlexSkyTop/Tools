public final class s {
   private final byte[] a = new byte[2048];
   private int a;
   private int b;

   public final int a() {
      synchronized(this) {
         return this.b;
      }
   }

   public final int a(byte[] var1, int var2, int var3) {
      if (var3 > var1.length) {
         throw new IllegalArgumentException("length + offset > buffer.length");
      } else if (var3 < 0) {
         throw new IllegalArgumentException("length < 0");
      } else if (var3 == 0) {
         return 0;
      } else {
         synchronized(this) {
            while(this.b == 0) {
               this.wait();
            }

            int var5 = 0;

            int var6;
            boolean var7;
            int var8;
            for(var7 = (var6 = this.a.length) == this.b; var3 > 0 && this.b > 0; var5 += var8) {
               var8 = Math.min(var6 - this.a, this.b);
               var8 = Math.min(var3, var8);
               System.arraycopy(this.a, this.a, var1, var2, var8);
               this.a += var8;
               if (this.a >= var6) {
                  this.a = 0;
               }

               this.b -= var8;
               var3 -= var8;
               var2 += var8;
            }

            if (var7) {
               this.notify();
            }

            return var5;
         }
      }
   }

   public final void a(byte[] var1, int var2, int var3) {
      if (var3 + var2 > var1.length) {
         throw new IllegalArgumentException("length + offset > buffer.length");
      } else if (var3 < 0) {
         throw new IllegalArgumentException("length < 0");
      } else if (var3 != 0) {
         synchronized(this) {
            int var5 = this.a.length;

            boolean var6;
            int var8;
            for(var6 = this.b == 0; var3 > 0; var3 -= var8) {
               while(var5 == this.b) {
                  this.wait();
               }

               int var7;
               if ((var7 = this.a + this.b) >= var5) {
                  var7 -= var5;
                  var8 = this.a - var7;
               } else {
                  var8 = var5 - var7;
               }

               var8 = Math.min(var8, var3);
               System.arraycopy(var1, var2, this.a, var7, var8);
               var2 += var8;
               this.b += var8;
            }

            if (var6) {
               this.notify();
            }

         }
      }
   }
}
