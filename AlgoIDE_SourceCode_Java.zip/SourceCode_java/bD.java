public final class bD extends aK {
   public bD(aE var1) {
      super(var1);
   }

   public final void a() {
      StringBuilder var1 = new StringBuilder();

      for(char var2 = this.a(); Character.isLetterOrDigit(var2) || var2 == '_'; var2 = this.b()) {
         var1.append(var2);
      }

      super.a = var1.toString();
      if (aL.b.containsKey(super.a.toLowerCase())) {
         super.a = (String)aL.b.get(super.a.toLowerCase());
      }

      bD var10000;
      Object var10001;
      if (super.a == null) {
         var10000 = this;
         var10001 = aL.az;
      } else {
         var10000 = this;
         var10001 = aL.a.containsKey(super.a.toLowerCase()) ? (aG)aL.a.get(super.a.toLowerCase()) : aL.av;
      }

      var10000.a = (aG)var10001;
   }
}
