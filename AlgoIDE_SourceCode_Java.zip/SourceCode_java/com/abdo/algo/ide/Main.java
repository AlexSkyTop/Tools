package com.abdo.algo.ide;

import javax.swing.SwingUtilities;

public class Main {
   public static void main(String[] var0) {
      SwingUtilities.invokeLater(() -> {
         (new .d()).setVisible(true);
      });
   }
}
