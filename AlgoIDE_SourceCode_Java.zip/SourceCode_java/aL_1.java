import java.util.HashSet;
import java.util.Hashtable;

public enum aL implements aG {
   a,
   b,
   c,
   d,
   e,
   f,
   g,
   h,
   i,
   j,
   k,
   l,
   m,
   n,
   o,
   p,
   q,
   r,
   s,
   t,
   u,
   v,
   w,
   x,
   y,
   z,
   A,
   B,
   C,
   D,
   E,
   F,
   G,
   H,
   aB,
   I,
   J,
   K("+"),
   L("-"),
   M("*"),
   N("/"),
   O("<-"),
   P("←"),
   Q("->"),
   R(":="),
   S("."),
   T(","),
   U(";"),
   V(":"),
   aC("'"),
   W("&"),
   X("&&"),
   Y("||"),
   aD("|"),
   Z("="),
   aa("=="),
   ab("<>"),
   ac("<"),
   ad("<="),
   ae(">="),
   af("!="),
   ag("≠"),
   ah(">"),
   ai("("),
   aj(")"),
   ak("!"),
   al("["),
   am("]"),
   aE("{"),
   aF("}"),
   an("^"),
   ao("%"),
   ap("+="),
   aq("-="),
   ar("*="),
   as("/="),
   at("?"),
   au(".."),
   av,
   aw,
   ax,
   ay,
   az,
   aA;

   private static final int a = K.ordinal();
   private static final int b = au.ordinal();
   public final String a;
   public static final Hashtable a;
   public static final Hashtable b;
   public static final HashSet a;
   public static final HashSet b;
   public static final HashSet c;
   public static final Hashtable c;

   private aL() {
      this.a = this.toString().toLowerCase();
   }

   private aL(String var3) {
      this.a = var3;
   }

   static {
      (a = new Hashtable()).put("et", a);
      a.put("tableau", b);
      a.put("debut", c);
      a.put("début", c);
      a.put("cas", d);
      a.put("selon", d);
      a.put("const", e);
      a.put("constante", e);
      a.put("constantes", e);
      a.put("div", f);
      a.put("faire", g);
      a.put("sinon", h);
      a.put("fin", i);
      a.put("pour", j);
      a.put("si", l);
      a.put("mod", m);
      a.put("non", n);
      a.put("de", o);
      a.put("allant", E);
      a.put("ou", p);
      a.put("algorithme", r);
      a.put("repeter", t);
      a.put("répéter", t);
      a.put("finsi", u);
      a.put("fsi", u);
      a.put("fintantque", x);
      a.put("ftantque", x);
      a.put("finpour", v);
      a.put("fpour", v);
      a.put("pas", z);
      a.put("alors", A);
      a.put("à", B);
      a.put("À", B);
      a.put("jusqua", F);
      a.put("var", G);
      a.put("variable", G);
      a.put("variables", G);
      a.put("tantque", H);
      a.put("fincas", w);
      a.put("fcas", w);
      a.put("finselon", w);
      a.put("fselon", w);
      a.put("fonction", k);
      a.put("procedure", q);
      a.put("procédure", q);
      a.put("retourner", y);
      a.put("retourne", y);
      a.put("structure", s);
      a.put("struct", s);
      a.put("enregistrement", s);
      a.put("type", C);
      a.put("autre", D);
      a.put("autres", D);
      a.put("vaut", J);
      a.put("dans", aB);
      a.put("sinonsi", I);
      (b = new Hashtable(22)).put("réel", "reel");
      b.put("reels", "reel");
      b.put("réels", "reel");
      b.put("caractère", "caractere");
      b.put("caracteres", "caractere");
      b.put("caractères", "caractere");
      b.put("booléen", "booleen");
      b.put("booleens", "booleen");
      b.put("booléens", "booleen");
      b.put("entiers", "entier");
      b.put("chaîne", "chaine");
      b.put("écrire", "ecrire");
      b.put("Écrire", "ecrire");
      b.put("écrireln", "ecrireln");
      b.put("Écrireln", "ecrireln");
      b.put("afficher", "ecrire");
      b.put("affiche", "ecrire");
      b.put("afficheln", "ecrireln");
      b.put("afficherln", "ecrireln");
      b.put("sqrt", "racine");
      b.put("saisir", "lire");
      b.put("saisirln", "lireln");
      (a = new HashSet(29)).add("abs");
      a.add("arctan");
      a.add("tan");
      a.add("cos");
      a.add("exp");
      a.add("ln");
      a.add("log");
      a.add("arrondi");
      a.add("sin");
      a.add("racine");
      a.add("long");
      a.add("taille");
      a.add("val");
      a.add("pos");
      a.add("convch");
      a.add("alea");
      a.add("copie");
      a.add("chr");
      a.add("asc");
      a.add("sqrt");
      a.add("arcsin");
      a.add("arccos");
      a.add("cosh");
      a.add("sinh");
      a.add("tanh");
      a.add("ecrire");
      a.add("ecrireln");
      a.add("lire");
      a.add("lireln");
      (b = new HashSet(2)).add("vrai");
      b.add("faux");
      (c = new HashSet(5)).add("entier");
      c.add("reel");
      c.add("caractere");
      c.add("chaine");
      c.add("booleen");
      c = new Hashtable(b - a + 1);
      aL[] var0 = values();

      for(int var1 = a; var1 <= b; ++var1) {
         c.put(var0[var1].a, var0[var1]);
      }

   }
}
