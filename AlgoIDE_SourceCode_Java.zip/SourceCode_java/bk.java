import java.util.EnumSet;

public final class bk extends bc {
   private static EnumSet a;

   public bk(aI var1) {
      super(var1);
   }

   public final bL a(aF var1, bL var2) {
      var1 = this.a(a);
      (new bd(this)).a(var1, var2);
      return null;
   }

   static {
      (a = EnumSet.of(aL.r, aL.U)).addAll(bc.b);
   }
}
