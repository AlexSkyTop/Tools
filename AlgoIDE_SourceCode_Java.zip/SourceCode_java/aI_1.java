import java.util.ArrayList;
import java.util.EnumSet;

public class aI extends aC {
   public final aH a = new aH();

   public aI(aJ var1, ca var2, V var3) {
      super(var1, var2, var3);
   }

   public aI(aI var1) {
      super(var1);
   }

   public final void a() {
      bM var10000 = super.a;
      V var2 = super.a;
      bM var1 = var10000;
      V var3 = var2;
      bM var7 = var10000;
      bV.b = var10000.a("entier");
      (bV.b = bN.a(cc.a)).a(bV.b);
      bV.b.a(bU.c);
      bV.b.a(bV.b);
      bV.c = var7.a("reel");
      (bV.c = bN.a(cc.a)).a(bV.c);
      bV.c.a(bU.c);
      bV.c.a(bV.c);
      bV.d = var7.a("booleen");
      (bV.d = bN.a(cc.b)).a(bV.d);
      bV.d.a(bU.c);
      bV.d.a(bV.d);
      bV.e = var7.a("caractere");
      (bV.e = bN.a(cc.a)).a(bV.e);
      bV.e.a(bU.c);
      bV.e.a(bV.e);
      bV.a = var7.a("chaine");
      bV.a = bN.a(cc.d);
      bV.a.a(bU.c);
      bV.a.a(bV.a);
      bP var8;
      (var8 = bN.a(cc.c)).a(cd.b, bV.b);
      var8.a(cd.c, var3.a.get());
      var8.a(cd.d, var3.a.get());
      bV.a.a(cd.e, var8);
      bV.a.a(cd.g, 1);
      bV.a.a(cd.f, bV.e);
      bV.a.a(bV.a);
      bN.a(cc.a);
      (bV.f = var1.a("faux")).a(bU.b);
      bV.f.a(bV.d);
      bV.f.a(bZ.a, 0);
      (bV.g = var1.a("vrai")).a(bU.b);
      bV.g.a(bV.d);
      bV.g.a(bZ.a, 1);
      ArrayList var9;
      (var9 = new ArrayList()).add(bV.f);
      var9.add(bV.g);
      bV.d.a(cd.a, var9);
      bV.i = bV.a(var1, bU.j, "ecrire", bW.f);
      bV.a(var1, bU.j, "ecrireln", bW.g);
      bV.h = bV.a(var1, bU.j, "lire", bW.d);
      bV.a(var1, bU.j, "lireln", bW.e);
      bV.a(var1, bU.k, "abs", bW.h);
      bV.a(var1, bU.k, "arctan", bW.i);
      bV.a(var1, bU.k, "tan", bW.t);
      bV.a(var1, bU.k, "cos", bW.j);
      bV.a(var1, bU.k, "exp", bW.k);
      bV.a(var1, bU.k, "ln", bW.l);
      bV.a(var1, bU.k, "log", bW.m);
      bV.a(var1, bU.k, "arrondi", bW.n);
      bV.a(var1, bU.k, "sin", bW.o);
      bV.a(var1, bU.k, "racine", bW.p);
      bV.a(var1, bU.k, "long", bW.q);
      bV.a(var1, bU.k, "taille", bW.b);
      bV.a(var1, bU.k, "val", bW.c);
      bV.a(var1, bU.k, "pos", bW.r);
      bV.a(var1, bU.k, "convch", bW.s);
      bV.a(var1, bU.k, "alea", bW.u);
      bV.a(var1, bU.k, "copie", bW.v);
      bV.a(var1, bU.k, "chr", bW.w);
      bV.a(var1, bU.k, "asc", bW.x);
      bV.a(var1, bU.k, "arcsin", bW.y);
      bV.a(var1, bU.k, "arccos", bW.z);
      bV.a(var1, bU.k, "cosh", bW.A);
      bV.a(var1, bU.k, "sinh", bW.B);
      bV.a(var1, bU.k, "tanh", bW.C);
      aF var5 = super.a.a();
      (new bk(this)).a(var5, (bL)null);
      aF var10 = super.a.a;
      aE var6;
      if ((var6 = super.a.a).a != null) {
         try {
            var6.a.close();
            return;
         } catch (Exception var4) {
         }
      }

   }

   public final aF a(EnumSet var1) {
      aF var2 = super.a.a;
      if (!var1.contains(var2.a)) {
         aH var10000 = this.a;
         aH.a(var2, aM.K);

         while(!((var2 = super.a.a()) instanceof aB) && !var1.contains(var2.a)) {
         }
      }

      return var2;
   }
}
