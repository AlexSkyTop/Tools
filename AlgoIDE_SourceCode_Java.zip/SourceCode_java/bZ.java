public enum bZ {
   a,
   b,
   c,
   d,
   e,
   f,
   g;
}
