import java.util.EnumSet;
import java.util.HashMap;

public final class aP extends bq {
   boolean a = false;
   private static final EnumSet a;
   private static final HashMap a;

   public aP(bq var1) {
      super(var1);
   }

   public final bH a(aF var1, boolean var2) {
      // $FF: Couldn't be decompiled
   }

   static {
      a = EnumSet.of(aL.O, aL.Z, aL.Q, aL.P, aL.R);
      (a = new HashMap()).put(aL.ap, bT.t);
      a.put(aL.aq, bT.u);
      a.put(aL.ar, bT.x);
      a.put(aL.as, bT.z);
   }
}
