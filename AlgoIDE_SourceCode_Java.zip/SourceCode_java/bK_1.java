import java.util.ArrayList;

public interface bK {
   int a();

   bL a(String var1);

   bL b(String var1);

   ArrayList a();

   String a();

   void a(String var1);

   Boolean a();

   void a(Boolean var1);
}
