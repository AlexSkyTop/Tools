import java.util.EnumSet;

class bu extends aI {
   static final EnumSet b;

   protected bu(aI var1) {
      super(var1);
   }

   public bP a(aF var1) {
      // $FF: Couldn't be decompiled
   }

   static {
      (b = bo.a.clone()).add(aL.b);
      b.add(aL.s);
      b.add(aL.U);
   }
}
