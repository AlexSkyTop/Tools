import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

final class k extends MouseAdapter {
   // $FF: synthetic field
   private d a;

   k(d var1) {
      this.a = var1;
      super();
   }

   public final void mouseClicked(MouseEvent var1) {
      if (var1.getClickCount() == 2) {
         d.a(this.a).a((String)d.a(this.a).getSelectedValue());
      } else {
         if (var1.getClickCount() == 1) {
            d.a(this.a).setEnabled(true);
         }

      }
   }
}
