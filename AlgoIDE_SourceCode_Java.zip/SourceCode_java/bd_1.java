import java.util.EnumSet;

public final class bd extends bc {
   private static int a = 0;
   private static final EnumSet a;
   private static final EnumSet f;
   private static final EnumSet g;
   private static final EnumSet h;
   private static final EnumSet i;

   public bd(bc var1) {
      super(var1);
   }

   public final bL a(aF var1, bL var2) {
      // $FF: Couldn't be decompiled
   }

   static {
      (a = bc.b.clone()).add(aL.G);
      a.add(aL.av);
      a.add(aL.aj);
      (f = bc.b.clone()).add(aL.ai);
      f.add(aL.U);
      f.add(aL.V);
      (g = f.clone()).remove(aL.ai);
      g.add(aL.aj);
      (h = EnumSet.of(aL.V, aL.aj, aL.U)).addAll(bc.b);
      (i = EnumSet.of(aL.T, aL.V, aL.av, aL.aj, aL.U)).addAll(bc.b);
   }
}
