public enum af {
   a("Valeur non initialisée"),
   l("Taille du tableau invalide"),
   b("Valeur hors plage"),
   c("Division par zéro"),
   d("Argument de fonction standard non valide"),
   e("Le format du nombre n'est pas valide"),
   f("Entrée invalide"),
   g("Valeur hors limites"),
   h("Indice de tableau hors limites"),
   i("Type d'indice invalide"),
   j("Accéder à une adresse mémoire invalide"),
   m("Erreur inconnue"),
   k("Maximum number of iterations exceeded");

   private final String a;

   private af(String var3) {
      this.a = var3;
   }

   public final String toString() {
      return this.a;
   }
}
