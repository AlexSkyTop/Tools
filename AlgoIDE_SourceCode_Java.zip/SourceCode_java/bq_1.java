import java.util.EnumSet;

public class bq extends aI {
   protected static final EnumSet b;
   protected static final EnumSet c;

   public bq(aI var1) {
      super(var1);
   }

   public bH a(aF var1) {
      // $FF: Couldn't be decompiled
   }

   protected static void a(bH var0, aF var1) {
      if (var0 != null) {
         var0.a(bR.a, var1.a);
      }

   }

   protected final void a(aF var1, bH var2, aL var3) {
      EnumSet var4;
      (var4 = b.clone()).add(var3);
      var4.add(aL.aA);
      if (var3 == aL.h) {
         var4.add(aL.u);
      }

      var4.add(aL.I);

      for(; !(var1 instanceof aB); var1 = this.a(var4)) {
         if (var3 == aL.h) {
            if (var1.a == aL.h || var1.a == aL.u || var1.a == aL.I) {
               break;
            }
         } else if (var1.a == var3) {
            break;
         }

         bH var5 = this.a(var1);
         var2.a(var5);
         if (super.a.a.a == aL.U) {
            super.a.a();
         }
      }

   }

   static {
      b = EnumSet.of(aL.c, aL.d, aL.j, aL.l, aL.t, aL.H, aL.av, aL.U, aL.y);
      c = EnumSet.of(aL.U, aL.i, aL.h, aL.F, aL.S, aL.I);
   }
}
