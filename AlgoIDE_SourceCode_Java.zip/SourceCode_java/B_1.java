import java.util.prefs.Preferences;

public final class B {
   private static B a;
   public final Preferences a = Preferences.userRoot().node("algoide/ui");

   private B() {
   }

   public static synchronized B a() {
      if (a == null) {
         a = new B();
      }

      return a;
   }

   public final boolean a() {
      return this.a.getBoolean("CASE_SENSITIVE_KEY", false);
   }

   public final int a() {
      return this.a.getInt("START_INDEX_ARRAY_KEY", 1);
   }

   public final boolean b() {
      return this.a.getBoolean("USE_DEFAULT_VALUES_KEY", false);
   }

   public final boolean c() {
      return this.a.getBoolean("AUTO_INDENT_KEY", true);
   }

   public final int b() {
      return this.a.getInt("TEXT_SIZE_KEY", 12);
   }

   public final boolean d() {
      return this.a.getBoolean("AUTO_PAIR_KEY", true);
   }

   public final boolean e() {
      return this.a.getBoolean("HIGHLIGHT_CURRENT_LINE_KEY", true);
   }

   public final boolean f() {
      return this.a.getBoolean("AUTO_COMPLETE_KEY", true);
   }

   public final boolean g() {
      return this.a.getBoolean("WITH_NEW_LINE_KEY", false);
   }
}
