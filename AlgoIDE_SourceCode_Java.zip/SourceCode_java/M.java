import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;
import javax.swing.DefaultListModel;

public final class M {
   public final ArrayList a;
   public final Preferences a;
   public final DefaultListModel a;

   public M(DefaultListModel var1) {
      this.a = var1;
      this.a = Preferences.userRoot().node("algoide/items");
      this.a = new ArrayList();

      try {
         ArrayList var3 = new ArrayList(Arrays.asList(this.a.keys()));
         if (this.a() != null) {
            var3.remove("current_key");
         }

         Iterator var2 = var3.iterator();

         while(var2.hasNext()) {
            String var5 = (String)var2.next();
            var1.addElement(var5);
         }

      } catch (BackingStoreException var4) {
      }
   }

   public final String a(String var1) {
      return this.a.get(var1, (String)null);
   }

   public final void a(String var1, String var2) {
      this.a.put(var1, var2);
      this.a.addElement(var1);
   }

   public final void a(String var1) {
      this.a.put("current_key", var1);
      this.b(var1, this.a(var1));
   }

   public final String a() {
      return this.a.get("current_key", "");
   }

   private void b(String var1, String var2) {
      Iterator var3 = this.a.iterator();

      while(var3.hasNext()) {
         ((K)var3.next()).onCurrentFileChange(var1, var2);
      }

   }
}
