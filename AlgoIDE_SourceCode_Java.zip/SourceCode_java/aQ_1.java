// $FF: synthetic class
final class aQ {
   // $FF: synthetic field
   static final int[] a = new int[aL.values().length];

   static {
      try {
         a[aL.ap.ordinal()] = 1;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a[aL.aq.ordinal()] = 2;
      } catch (NoSuchFieldError var2) {
      }

      try {
         a[aL.ar.ordinal()] = 3;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[aL.as.ordinal()] = 4;
      } catch (NoSuchFieldError var0) {
      }
   }
}
