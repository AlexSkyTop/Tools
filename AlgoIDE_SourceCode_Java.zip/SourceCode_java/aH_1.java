public final class aH {
   public static void a(aF var0, aM var1) {
      StringBuilder var2 = new StringBuilder();
      StringBuilder var3;
      (var3 = new StringBuilder()).append(var0.b).append('\n');
      int var4 = var0.b;

      for(int var5 = 1; var5 <= var4; ++var5) {
         var3.append(' ');
      }

      var3.append('^');
      var2.append("*** ");
      var2.append(var1.toString());
      if (var0.a != null) {
         var2.append(" [en \"").append(var0.a).append("\"]");
      }

      throw new cj(var3.toString(), var2.toString(), var0);
   }
}
