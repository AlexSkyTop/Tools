public final class cf {
   public final int a;
   private final Object a;

   public cf(int var1, Object var2) {
      this.a = var1;
      this.a = var2;
   }
}
