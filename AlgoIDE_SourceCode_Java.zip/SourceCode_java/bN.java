public final class bN {
   public static bP a(cc var0) {
      return new ce(var0);
   }

   public static bP a(String var0) {
      return new ce(var0);
   }
}
