import java.util.ArrayList;

public final class az extends ArrayList implements ae {
   public az() {
      this.add((Object)null);
   }

   public final Y a(int var1) {
      return (Y)this.get(var1);
   }

   public final void a(int var1, av var2) {
      if (var1 >= this.size()) {
         this.add(var2);
      } else {
         Y var3 = (Y)this.get(var1);
         this.set(var1, var2.a(var3));
      }
   }

   public final void a(int var1) {
      int var2 = this.size() - 1;
      Y var3;
      if ((var3 = ((Y)this.get(var1)).a()) != null) {
         this.set(var1, var3);
      } else {
         if (var1 == var2) {
            this.remove(var2);
         }

      }
   }
}
