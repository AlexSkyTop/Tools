import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

final class p extends AbstractAction {
   // $FF: synthetic field
   private d a;

   p(d var1) {
      this.a = var1;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      String var3 = d.a(this.a).a();
      String var2 = d.a(this.a).getText();
      d.a(this.a, d.a(this.a).a(var3), var2);
   }
}
