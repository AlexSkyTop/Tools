public interface Y {
   Z a(String var1);

   int a();

   Y a();

   Y a(Y var1);

   boolean a();

   void a();
}
