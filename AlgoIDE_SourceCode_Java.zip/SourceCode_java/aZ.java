import java.util.EnumSet;

public final class aZ extends bq {
   private static final EnumSet a;

   public aZ(bg var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      super.a.a();
      bH var2 = bG.a(bT.K);
      bg var3 = new bg(this);

      bP var4;
      do {
         var1 = this.a(bg.a);
         bH var6 = var3.a(var1);
         var2.a(var6);
         var4 = var6.a();
         aG var5;
         if ((var5 = (var1 = this.a(a)).a) == aL.T) {
            var1 = super.a.a();
         } else if (var5 != aL.am) {
            aH var10000 = super.a;
            aH.a(var1, aM.A);
         }
      } while(var1.a != aL.am);

      bP var7;
      (var7 = bN.a(cc.f)).a(cd.g, var2.a().size());
      var7.a(cd.f, var4);
      var2.a(var7);
      super.a.a();
      return var2;
   }

   static {
      EnumSet.of(aL.V, aL.aj, aL.U).addAll(bc.b);
      (a = EnumSet.of(aL.T, aL.V, aL.av, aL.am, aL.U)).addAll(bg.a);
   }
}
