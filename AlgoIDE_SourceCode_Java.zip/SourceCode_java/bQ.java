public final class bQ implements bF {
   private bH a;

   public final bH a(bH var1) {
      this.a = var1;
      return this.a;
   }

   public final bH a() {
      return this.a;
   }
}
