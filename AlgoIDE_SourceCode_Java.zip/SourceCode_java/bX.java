import java.util.ArrayList;
import java.util.HashMap;

public final class bX extends HashMap implements bL {
   private final String a;
   private final bY a;
   private bU a;
   private bP a;
   private final ArrayList a;

   public bX(String var1, bY var2) {
      this.a = var1;
      this.a = var2;
      this.a = new ArrayList();
   }

   public final String a() {
      return this.a;
   }

   public final bK a() {
      return this.a;
   }

   public final void a(bU var1) {
      this.a = var1;
   }

   public final bE a() {
      return this.a;
   }

   public final void a(bP var1) {
      this.a = var1;
   }

   public final bP a() {
      return this.a;
   }

   public final void a(int var1) {
      this.a.add(var1);
   }

   public final void a(bZ var1, Object var2) {
      this.put(var1, var2);
   }

   public final Object a(bZ var1) {
      return this.get(var1);
   }
}
