import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

final class j extends AbstractAction {
   // $FF: synthetic field
   private d a;

   j(d var1) {
      this.a = var1;
      super();
   }

   public final void actionPerformed(ActionEvent var1) {
      JOptionPane.showMessageDialog(this.a, "ALgoIDE 4.0.1-beta\nCopyright 2022 By EL-HAOUZI ABDESSAMAD\nEmail:elhaouzi.abdessamad@gmail.com", "About", 1, cm.a("/icons/48/algo.png"));
   }
}
