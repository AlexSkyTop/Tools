public final class bB extends aK {
   public bB(aE var1) {
      super(var1);
   }

   public final void a() {
      char var1 = this.a();
      super.a = Character.toString(var1);
      super.a = null;
      switch(var1) {
      case '!':
      case '*':
      case '+':
      case '/':
      case ':':
      case '=':
      case '>':
         if ((var1 = this.b()) == '=') {
            super.a = super.a + var1;
            this.b();
         }
         break;
      case '%':
      case '\'':
      case '(':
      case ')':
      case ',':
      case ';':
      case '?':
      case '[':
      case ']':
      case '^':
      case '{':
      case '}':
      case '←':
      case '≠':
         this.b();
         break;
      case '&':
         if ((var1 = this.b()) == '&') {
            super.a = super.a + var1;
            this.b();
         }
         break;
      case '-':
         if ((var1 = this.b()) == '>' || var1 == '=') {
            super.a = super.a + var1;
            this.b();
         }
         break;
      case '.':
         if ((var1 = this.b()) == '.') {
            super.a = super.a + var1;
            this.b();
         }
         break;
      case '<':
         if ((var1 = this.b()) == '=' || var1 == '>' || var1 == '-') {
            super.a = super.a + var1;
            this.b();
         }
         break;
      case '|':
         if ((var1 = this.b()) == '|') {
            super.a = super.a + var1;
            this.b();
         }
         break;
      default:
         this.b();
         super.a = aL.az;
         super.a = aM.e;
      }

      if (super.a == null) {
         super.a = (aG)aL.c.get(super.a);
      }

   }
}
