import java.util.Iterator;

public final class an extends at {
   public an(at var1) {
      super(var1);
   }

   public final Object a(bH var1) {
      at var2 = new at(this);
      Iterator var4 = var1.a().iterator();

      bH var3;
      do {
         if (!var4.hasNext()) {
            return null;
         }

         var3 = (bH)var4.next();
         if (super.a.c.get()) {
            throw new InterruptedException();
         }

         var2.a(var3);
      } while(!aL.y.a.equals(var3.a(bR.d)));

      super.a.b();
      return null;
   }
}
