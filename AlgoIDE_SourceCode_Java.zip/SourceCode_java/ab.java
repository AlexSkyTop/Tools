import java.io.PrintStream;

public class ab extends W {
   protected static int a = 0;
   public ag a = new ag();
   public aD a;
   public PrintStream a;
   private aa a;

   public ab(ca var1, aA var2, aJ var3, PrintStream var4, V var5) {
      super(var1, var2, var5);
      this.a = var3;
      this.a = var4;
   }

   public ab(ab var1) {
      super(var1 != null ? var1.a : null, var1 != null ? var1.a : null, var1 != null ? var1.a : null);
      if (var1 != null) {
         this.a = var1.a;
         this.a = var1.a;
         super.a = var1.a;
         this.a = var1.a;
         this.a = var1.a;
         super.a = var1.a;
         super.a = var1.a;
      }

   }

   public final void a() {
      bL var1 = super.a.a();
      bH var2;
      (var2 = bG.a(bT.e)).a(bR.b, var1);
      (new aj(this)).a(var2);
   }
}
