import java.util.EnumSet;

final class bo extends bu {
   static final EnumSet a;

   protected bo(bu var1) {
      super(var1);
   }

   public final bP a(aF var1) {
      // $FF: Couldn't be decompiled
   }

   static {
      (a = ba.a.clone()).add(aL.ai);
      a.add(aL.T);
      a.add(aL.U);
   }
}
