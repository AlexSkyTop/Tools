public final class av implements Y {
   private final bL a;
   private Y a;
   private final int a;
   private final ad a;
   private boolean a;

   public av(bL var1) {
      bK var2 = (bK)var1.a(bZ.c);
      this.a = var1;
      this.a = var2.a();
      this.a = ac.a(var2);
      this.a = false;
   }

   public final Z a(String var1) {
      return this.a.a(var1);
   }

   public final int a() {
      return this.a;
   }

   public final Y a() {
      return this.a;
   }

   public final Y a(Y var1) {
      this.a = var1;
      return this;
   }

   public final boolean a() {
      return this.a;
   }

   public final void a() {
      this.a = true;
   }
}
