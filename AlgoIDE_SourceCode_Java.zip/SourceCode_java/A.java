public final class A {
   private int[] a = new int[2048];
   private int a = 0;
   private int b = 0;

   public final synchronized int a() {
      while(this.a == this.b) {
         try {
            this.wait();
         } catch (InterruptedException var2) {
         }
      }

      int var1 = this.a[this.a];
      ++this.a;
      if (this.a >= this.a.length) {
         this.a = 0;
      }

      return var1;
   }

   public final synchronized void a(int var1) {
      this.a[this.b] = var1;
      ++this.b;
      if (this.b >= this.a.length) {
         this.b = 0;
      }

      if (this.a == this.b) {
         ++this.a;
         if (this.a >= this.a.length) {
            this.a = 0;
         }
      }

      this.notify();
   }
}
