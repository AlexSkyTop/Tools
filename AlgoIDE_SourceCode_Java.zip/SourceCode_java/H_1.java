import java.util.Collections;
import java.util.List;

public final class H implements Runnable {
   private final String a;
   // $FF: synthetic field
   private F a;

   public H(F var1, String var2) {
      this.a = var1;
      super();
      this.a = var2;
   }

   public final void run() {
      List var1 = (new a((t)null, F.a(this.a), F.a(this.a))).a(this.a);
      F.a(this.a).clear();
      F.a(this.a).addAll(cl.a);
      F.a(this.a).addAll(var1);
      Collections.sort(F.a(this.a));
   }
}
