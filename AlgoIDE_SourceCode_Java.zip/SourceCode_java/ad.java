public interface ad {
   Z a(String var1);
}
