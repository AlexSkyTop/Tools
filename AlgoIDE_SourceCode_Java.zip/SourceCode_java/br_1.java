// $FF: synthetic class
final class br {
   // $FF: synthetic field
   static final int[] a;
   // $FF: synthetic field
   static final int[] b = new int[aL.values().length];

   static {
      try {
         b[aL.c.ordinal()] = 1;
      } catch (NoSuchFieldError var13) {
      }

      try {
         b[aL.av.ordinal()] = 2;
      } catch (NoSuchFieldError var12) {
      }

      try {
         b[aL.t.ordinal()] = 3;
      } catch (NoSuchFieldError var11) {
      }

      try {
         b[aL.H.ordinal()] = 4;
      } catch (NoSuchFieldError var10) {
      }

      try {
         b[aL.j.ordinal()] = 5;
      } catch (NoSuchFieldError var9) {
      }

      try {
         b[aL.l.ordinal()] = 6;
      } catch (NoSuchFieldError var8) {
      }

      try {
         b[aL.d.ordinal()] = 7;
      } catch (NoSuchFieldError var7) {
      }

      try {
         b[aL.y.ordinal()] = 8;
      } catch (NoSuchFieldError var6) {
      }

      a = new int[bU.values().length];

      try {
         a[bU.d.ordinal()] = 1;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a[bU.f.ordinal()] = 2;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a[bU.g.ordinal()] = 3;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a[bU.l.ordinal()] = 4;
      } catch (NoSuchFieldError var2) {
      }

      try {
         a[bU.k.ordinal()] = 5;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[bU.j.ordinal()] = 6;
      } catch (NoSuchFieldError var0) {
      }
   }
}
