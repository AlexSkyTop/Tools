public abstract class aD {
   public final aE a;
   public aF a;

   public aD(aE var1) {
      this.a = var1;
   }

   public final aF a() {
      this.a = this.b();
      return this.a;
   }

   protected abstract aF b();

   public final char a() {
      return this.a.a();
   }

   public final char b() {
      return this.a.b();
   }
}
