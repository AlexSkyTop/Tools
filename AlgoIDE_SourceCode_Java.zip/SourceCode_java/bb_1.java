// $FF: synthetic class
final class bb {
   // $FF: synthetic field
   static final int[] a = new int[aL.values().length];

   static {
      try {
         a[aL.av.ordinal()] = 1;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a[aL.aw.ordinal()] = 2;
      } catch (NoSuchFieldError var2) {
      }

      try {
         a[aL.ax.ordinal()] = 3;
      } catch (NoSuchFieldError var1) {
      }

      try {
         a[aL.ay.ordinal()] = 4;
      } catch (NoSuchFieldError var0) {
      }
   }
}
