public final class aJ extends aD {
   public aJ(aE var1) {
      super(var1);
   }

   public final aF b() {
      aJ var1 = this;
      char var2 = this.a();

      while(true) {
         while(Character.isWhitespace(var2) || var2 == '/' && (var1.a.c() == '/' || var1.a.c() == '*') || var2 == '{' || var2 == 160) {
            if (var2 == '{') {
               while((var2 = var1.b()) != '}' && var2 != 0) {
               }

               if (var2 == '}') {
                  var2 = var1.b();
               }
            } else if (var2 != '/') {
               var2 = var1.b();
            } else if ((var2 = var1.b()) == '*') {
               while((var2 = var1.b()) != 0 && (var2 != '*' || var1.a.c() != '/')) {
               }

               if (var2 == '*') {
                  var1.b();
                  var2 = var1.b();
               }
            } else if (var2 == '/') {
               while((var2 = var1.b()) != '\n' && var2 != 0) {
               }

               if (var2 == '\n') {
                  var2 = var1.b();
               }
            }
         }

         char var3;
         Object var4;
         if ((var3 = this.a()) == 0) {
            var4 = new aB(super.a);
         } else if (!Character.isLetter(var3) && var3 != '_') {
            if (Character.isDigit(var3)) {
               var4 = new bA(super.a);
            } else if (var3 != '\'' && var3 != '"') {
               if (aL.c.containsKey(Character.toString(var3))) {
                  var4 = new bB(super.a);
               } else {
                  var4 = new bz(super.a, aM.e, Character.toString(var3));
                  this.b();
               }
            } else {
               var4 = new bC(super.a);
            }
         } else {
            var4 = new bD(super.a);
         }

         return (aF)var4;
      }
   }
}
