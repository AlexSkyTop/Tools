public final class bs extends bu {
   protected bs(bo var1) {
      super(var1);
   }

   public final bP a(aF var1) {
      bP var2 = bN.a(cc.c);
      Object var4 = null;
      aF var5 = var1;
      ba var6;
      Object var3 = (var6 = new ba(this)).a();
      bP var7 = var1.a == aL.av ? var6.a(var1) : ba.a(var3);
      var3 = this.a(var1, var3, var7);
      var1 = super.a.a;
      Boolean var8 = Boolean.FALSE;
      if (var1.a == aL.au) {
         var1 = super.a.a();
         var8 = Boolean.TRUE;
      }

      aG var9 = var1.a;
      aH var10000;
      bP var10;
      if (ba.a.contains((aL)var9)) {
         if (!var8) {
            var10000 = super.a;
            aH.a(var1, aM.t);
         }

         var5 = this.a(ba.a);
         var4 = var6.a();
         var10 = var5.a == aL.av ? var6.a(var5) : ba.a(var4);
         var4 = this.a(var5, var4, var10);
         if (var7 != null && var10 != null) {
            if (var7 != var10) {
               var10000 = super.a;
               aH.a(var5, aM.k);
            } else if (var3 != null && var4 != null && (Integer)var3 >= (Integer)var4) {
               var10000 = super.a;
               aH.a(var5, aM.n);
            }
         } else {
            var10000 = super.a;
            aH.a(var5, aM.d);
         }
      } else if (var9 != aL.am && var9 != aL.T) {
         var10000 = super.a;
         aH.a(var5, aM.k);
      } else {
         var4 = (Integer)var3 - 1 + super.a.a.get();
         var3 = super.a.a.get();
         var10 = var7;
         if ((var7 = ba.a(var3)) != null && var10 != null) {
            if (var7 != var10) {
               var10000 = super.a;
               aH.a(var5, aM.k);
            } else if ((Integer)var3 > (Integer)var4) {
               var10000 = super.a;
               aH.a(var5, aM.n);
            }
         } else {
            var10000 = super.a;
            aH.a(var5, aM.d);
         }
      }

      var2.a(cd.b, var7);
      var2.a(cd.c, var3);
      var2.a(cd.d, var4);
      return var2;
   }

   private Object a(aF var1, Object var2, bP var3) {
      if (var3 == null) {
         return var2;
      } else if (var3 == bV.b) {
         return var2;
      } else if (var3 == bV.e) {
         return Character.getNumericValue(((String)var2).charAt(0));
      } else if (var3.a() == cc.b) {
         return var2;
      } else {
         aH var10000 = super.a;
         aH.a(var1, aM.k);
         return var2;
      }
   }
}
