import java.util.ArrayList;

public interface bH {
   bI a();

   bH a();

   void a(bP var1);

   bP a();

   bH a(bH var1);

   ArrayList a();

   void a(bR var1, Object var2);

   Object a(bR var1);

   bH b();
}
