import java.io.BufferedReader;
import java.io.StringReader;

public final class aN {
   public static aC a(String var0, ca var1, V var2) {
      return new aI(new aJ(new aE(new BufferedReader(new StringReader(var0)))), var1, var2);
   }
}
