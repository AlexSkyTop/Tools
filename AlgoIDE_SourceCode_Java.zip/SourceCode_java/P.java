import java.awt.Color;
import java.util.regex.Matcher;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.text.AbstractDocument.DefaultDocumentEvent;

public final class P extends DefaultStyledDocument {
   private final Style a;
   private final Style b;
   private final Style c;
   private final Style d;
   private final Style e;
   private final Style f;
   private final Style g;
   private final Timer a = new Timer(700, (var1x) -> {
      P var5 = this;

      try {
         String var2 = var5.getText(0, var5.getLength());
         var5.a(0, var2.length(), (Style)var5.a);
         Matcher var3 = cl.a.matcher(var2);

         while(var3.find()) {
            var5.a(var3.start(), var3.end() - var3.start(), var5.b);
         }

         var3 = cl.b.matcher(var2);

         while(var3.find()) {
            var5.a(var3.start(), var3.end() - var3.start(), var5.c);
         }

         var3 = cl.c.matcher(var2);

         while(var3.find()) {
            var5.a(var3.start(), var3.end() - var3.start(), var5.d);
         }

         var3 = cl.d.matcher(var2);

         while(var3.find()) {
            var5.a(var3.start(), var3.end() - var3.start(), var5.e);
         }

         var3 = cl.e.matcher(var2);

         while(var3.find()) {
            var5.a(var3.start(), var3.end() - var3.start(), var5.f);
         }

         var3 = cl.f.matcher(var2);

         while(var3.find()) {
            var5.a(var3.start(), var3.end() - var3.start(), var5.g);
         }

      } catch (BadLocationException var4) {
      }
   });

   public P() {
      this.a.setCoalesce(true);
      this.a.setRepeats(false);
      this.a.start();
      StyleContext var1 = new StyleContext();
      this.a = var1.getStyle("default");
      this.b = var1.addStyle("commentStyle", (Style)null);
      StyleConstants.setForeground(this.b, Color.GRAY);
      this.c = var1.addStyle("stringStyle", (Style)null);
      StyleConstants.setForeground(this.c, Color.GREEN.darker());
      this.d = var1.addStyle("numberStyle", (Style)null);
      StyleConstants.setForeground(this.d, Color.CYAN);
      this.e = var1.addStyle("symbolStyle", (Style)null);
      StyleConstants.setForeground(this.e, Color.MAGENTA);
      this.f = var1.addStyle("keywordStyle", (Style)null);
      StyleConstants.setForeground(this.f, Color.BLUE);
      this.g = var1.addStyle("routingStyle", (Style)null);
      StyleConstants.setForeground(this.g, Color.BLUE);
   }

   public final void insertString(int var1, String var2, AttributeSet var3) {
      super.insertString(var1, var2, var3);
      if (this.a.isRunning()) {
         this.a.restart();
      } else {
         this.a.start();
      }
   }

   public final void remove(int var1, int var2) {
      super.remove(var1, var2);
      if (this.a.isRunning()) {
         this.a.restart();
      } else {
         this.a.start();
      }
   }

   protected final void insertUpdate(DefaultDocumentEvent var1, AttributeSet var2) {
      super.insertUpdate(var1, var2);
      if (this.a.isRunning()) {
         this.a.restart();
      } else {
         this.a.start();
      }
   }

   private void a(int var1, int var2, Style var3) {
      SwingUtilities.invokeLater(() -> {
         this.setCharacterAttributes(var1, var2, var3, true);
      });
   }
}
