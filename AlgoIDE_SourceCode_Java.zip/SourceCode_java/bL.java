public interface bL {
   String a();

   bK a();

   void a(bU var1);

   bE a();

   void a(bP var1);

   bP a();

   void a(int var1);

   void a(bZ var1, Object var2);

   Object a(bZ var1);
}
