public final class ag {
   public static void a(bH var0, af var1) {
      Integer var2 = null;

      StringBuilder var3;
      for(var3 = new StringBuilder(); var0 != null && var0.a(bR.a) == null; var0 = var0.a()) {
      }

      if (var0 != null) {
         var2 = (Integer)var0.a(bR.a);
      }

      var3.append("\nERREUR D'EXÉCUTION ");
      if (var2 != null) {
         var3.append(" À LA LIGNE ").append(var2);
      }

      var3.append(": ").append(var1.toString());
      throw new ck(var3.toString());
   }
}
