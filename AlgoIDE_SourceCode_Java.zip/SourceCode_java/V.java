import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class V {
   public final AtomicInteger a;
   public final AtomicBoolean a;
   public final AtomicBoolean b;
   public final AtomicBoolean c;
   public final AtomicBoolean d;
   public final AtomicBoolean e;

   public V(int var1, boolean var2, boolean var3, boolean var4) {
      this.a = new AtomicInteger(var1);
      this.a = new AtomicBoolean(var2);
      this.b = new AtomicBoolean(var3);
      this.e = new AtomicBoolean(var4);
      this.c = new AtomicBoolean(true);
      this.d = new AtomicBoolean(false);
   }
}
