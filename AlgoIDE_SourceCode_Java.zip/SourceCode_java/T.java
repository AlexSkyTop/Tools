import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.HashMap;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.Element;
import javax.swing.text.JTextComponent;
import javax.swing.text.StyleConstants;
import javax.swing.text.Utilities;

public final class T extends JPanel implements PropertyChangeListener, CaretListener, DocumentListener {
   private static final MatteBorder a;
   private N a;
   public boolean a;
   private int a;
   private Color a;
   private float a;
   private int b;
   private int c;
   private int d;
   private int e;
   private HashMap a;

   public T(N var1) {
      this(var1, (byte)0);
   }

   private T(N var1, byte var2) {
      this.a = var1;
      this.setFont(var1.getFont());
      this.a = 5;
      EmptyBorder var3 = new EmptyBorder(0, 5, 0, 5);
      this.setBorder(new CompoundBorder(a, var3));
      this.c = 0;
      this.a();
      this.a = Color.RED;
      this.a = 1.0F;
      this.b = 3;
      this.a();
      var1.getDocument().addDocumentListener(this);
      var1.addCaretListener(this);
      var1.addPropertyChangeListener("font", this);
   }

   private void a() {
      int var1 = Math.max(String.valueOf(this.a.getDocument().getDefaultRootElement().getElementCount()).length(), this.b);
      if (this.c != var1) {
         this.c = var1;
         var1 = this.getFontMetrics(this.getFont()).charWidth('0') * var1;
         Insets var2;
         var1 += (var2 = this.getInsets()).left + var2.right;
         Dimension var3;
         (var3 = this.getPreferredSize()).setSize(var1, 2146483647);
         this.setPreferredSize(var3);
         this.setSize(var3);
      }

   }

   public final void paintComponent(Graphics var1) {
      super.paintComponent(var1);
      FontMetrics var2 = this.a.getFontMetrics(this.a.getFont());
      Insets var3 = this.getInsets();
      int var4 = this.getSize().width - var3.left - var3.right;
      Rectangle var5 = var1.getClipBounds();
      int var6 = this.a.viewToModel(new Point(0, var5.y));
      int var19 = this.a.viewToModel(new Point(0, var5.y + var5.height));

      while(var6 <= var19) {
         try {
            int var11 = this.a.getCaretPosition();
            Element var12;
            if ((var12 = this.a.getDocument().getDefaultRootElement()).getElementIndex(var6) == var12.getElementIndex(var11)) {
               var1.setColor(this.a == null ? this.getForeground() : this.a);
            } else {
               var1.setColor(this.getForeground());
            }

            Element var22;
            int var23 = (var22 = this.a.getDocument().getDefaultRootElement()).getElementIndex(var6);
            String var7 = var22.getElement(var23).getStartOffset() == var6 ? String.valueOf(var23 + 1) : "";
            int var8 = var2.stringWidth(var7);
            var8 = (int)((float)(var4 - var8) * this.a) + var3.left;
            T var9 = this;
            Rectangle var24 = this.a.modelToView(var6);
            int var13 = var2.getHeight();
            int var14 = var24.y + var24.height;
            int var15 = 0;
            if (var24.height == var13) {
               var15 = var2.getDescent();
            } else {
               if (this.a == null) {
                  this.a = new HashMap();
               }

               int var10 = (var22 = this.a.getDocument().getDefaultRootElement()).getElementIndex(var6);
               Element var21 = var22.getElement(var10);

               for(var11 = 0; var11 < var21.getElementCount(); ++var11) {
                  AttributeSet var25;
                  String var26 = (String)(var25 = var21.getElement(var11).getAttributes()).getAttribute(StyleConstants.FontFamily);
                  Integer var27 = (Integer)var25.getAttribute(StyleConstants.FontSize);
                  String var16 = var26 + var27;
                  FontMetrics var17;
                  if ((var17 = (FontMetrics)var9.a.get(var16)) == null) {
                     Font var28 = new Font(var26, 0, var27);
                     var17 = var9.a.getFontMetrics(var28);
                     var9.a.put(var16, var17);
                  }

                  var15 = Math.max(var15, var17.getDescent());
               }
            }

            int var20 = var14 - var15;
            var1.drawString(var7, var8, var20);
            var6 = Utilities.getRowEnd(this.a, var6) + 1;
         } catch (Exception var18) {
            break;
         }
      }

   }

   public final void caretUpdate(CaretEvent var1) {
      int var2 = this.a.getCaretPosition();
      var2 = this.a.getDocument().getDefaultRootElement().getElementIndex(var2);
      if (this.e != var2) {
         this.getParent().repaint();
         this.e = var2;
      }

   }

   public final void changedUpdate(DocumentEvent var1) {
      this.b();
   }

   public final void insertUpdate(DocumentEvent var1) {
      this.b();
   }

   public final void removeUpdate(DocumentEvent var1) {
      this.b();
   }

   private void b() {
      SwingUtilities.invokeLater(new U(this));
   }

   public final void propertyChange(PropertyChangeEvent var1) {
      if (var1.getNewValue() instanceof Font) {
         if (this.a) {
            Font var2 = (Font)var1.getNewValue();
            this.setFont(var2);
            this.c = 0;
            this.a();
            return;
         }

         this.getParent().repaint();
      }

   }

   // $FF: synthetic method
   static JTextComponent a(T var0) {
      return var0.a;
   }

   // $FF: synthetic method
   static int a(T var0) {
      return var0.d;
   }

   // $FF: synthetic method
   static void a(T var0) {
      var0.a();
   }

   // $FF: synthetic method
   static int a(T var0, int var1) {
      return var0.d = var1;
   }

   static {
      a = new MatteBorder(0, 0, 0, 2, Color.GRAY);
   }
}
