public interface ae {
   Y a(int var1);

   void a(int var1, av var2);

   void a(int var1);
}
