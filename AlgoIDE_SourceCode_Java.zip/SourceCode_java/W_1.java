import java.util.Iterator;

public abstract class W {
   public cg a;
   public final bM a;
   public ah a;
   public V a;

   public W(bM var1, ah var2, V var3) {
      this.a = var1;
      this.a = var2;
      this.a = new cg();
      this.a = var3;
   }

   public abstract void a();

   public final void a(cf var1) {
      cg var10000 = this.a;
      cf var2 = var1;
      cg var3 = var10000;
      var10000.a = var2;
      Iterator var4 = var3.a.iterator();

      while(var4.hasNext()) {
         ((ch)var4.next()).a(var3.a);
      }

   }

   public final void b() {
      this.a.a.clear();
   }
}
