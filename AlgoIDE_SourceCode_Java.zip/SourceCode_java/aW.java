import java.util.EnumSet;
import java.util.HashSet;

public final class aW extends bq {
   private static final EnumSet a;
   private static final EnumSet d;
   private static final EnumSet e;

   public aW(bq var1) {
      super(var1);
   }

   public final bH a(aF var1) {
      // $FF: Couldn't be decompiled
   }

   static {
      (d = (a = EnumSet.of(aL.av, aL.aw, aL.K, aL.L, aL.ay)).clone()).add(aL.o);
      d.add(aL.J);
      d.addAll(bq.c);
      (e = a.clone()).add(aL.T);
      e.add(aL.V);
      e.addAll(bq.b);
      e.addAll(bq.c);
   }
}
