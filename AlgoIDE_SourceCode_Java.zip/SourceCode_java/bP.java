public interface bP {
   bO a();

   void a(bL var1);

   bL a();

   void a(cd var1, Object var2);

   Object a(cd var1);

   boolean a();

   bP a();
}
