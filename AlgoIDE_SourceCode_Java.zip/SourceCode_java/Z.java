public interface Z {
   void a(Object var1);

   Object a();
}
