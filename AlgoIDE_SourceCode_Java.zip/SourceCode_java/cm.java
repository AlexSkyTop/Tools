import java.io.File;
import java.net.URL;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.ImageIcon;

public final class cm {
   public static ImageIcon a(String var0) {
      URL var1;
      if ((var1 = C.class.getResource(var0)) != null) {
         return new ImageIcon(var1);
      } else {
         System.err.println("Couldn't find file: ".concat(String.valueOf(var0)));
         return null;
      }
   }

   public static String a(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         List var10000 = Files.readAllLines((new File(var0)).toPath());
         String var1 = "\n";
         List var2 = var10000;
         return String.join(var1, var2);
      } else {
         return "";
      }
   }

   public static List a(Set var0, Collection var1, HashSet var2) {
      ArrayList var3;
      (var3 = new ArrayList(var0.size() + var1.size() + var2.size())).addAll(var0);
      var3.addAll(var1);
      var3.addAll(var2);
      return var3;
   }
}
